import React, { useEffect, Suspense, lazy } from "react";
import { Header } from "../components/layout/Header";
import { Sidebar, MODULES } from "../components/layout/Sidebar";
import { PlaceholderModule } from "../components/layout/PlaceholderModule";
import { Booking, CustomTable, TableColumn, TableRow } from "../types";
import { 
  MapPin, 
  Sparkles, 
  ArrowRight, 
  Grid, 
  Smartphone, 
  BookOpen, 
  DollarSign, 
  Clock, 
  CheckCircle, 
  AlertTriangle 
} from "lucide-react";
import { useUiStore } from "../store/uiStore";
import { useTableStore } from "../store/tableStore";

const DriverManagement = lazy(() => import("../modules/drivers/DriverManagement").then(m => ({ default: m.DriverManagement })));
const VehicleManagement = lazy(() => import("../modules/vehicles/VehicleManagement").then(m => ({ default: m.VehicleManagement })));
const MechanicManagement = lazy(() => import("../modules/mechanics/MechanicManagement").then(m => ({ default: m.MechanicManagement })));
const PartyManagement = lazy(() => import("../modules/parties/PartyManagement").then(m => ({ default: m.PartyManagement })));
const LedgerManagement = lazy(() => import("../modules/ledger/LedgerManagement").then(m => ({ default: m.LedgerManagement })));

// Lazy Load Heavy Components for split chunking
const DynamicSheetDatabase = lazy(() => import("../components/tables/DynamicSheetDatabase").then(m => ({ default: m.DynamicSheetDatabase })));
const ChatSimulator = lazy(() => import("../modules/whatsapp/ChatSimulator").then(m => ({ default: m.ChatSimulator })));
const SetupGuide = lazy(() => import("../modules/sheets/SetupGuide").then(m => ({ default: m.SetupGuide })));
const WebhookViewer = lazy(() => import("../modules/webhooks/WebhookViewer").then(m => ({ default: m.WebhookViewer })));

// Lazy Load Firebase to avoid heavy boot
let firebaseLazy: any = null;
const lazyInitFirebase = async () => {
  if (!firebaseLazy) {
    const fb = await import("../services/firebase");
    const bg = await import("../services/bookings");
    firebaseLazy = { ...fb, ...bg };
  }
  return firebaseLazy;
};

export default function App() {
  const { 
    activeTab, setActiveTab, 
    geminiConfigured, setGeminiConfigured,
    appUrl, setAppUrl,
    userId, setUserId,
    isDarkMode, setIsDarkMode
  } = useUiStore();

  const {
    customTables, activeTableId,
    setCustomTables, setActiveTableId,
    addTable, updateTable, addColumn, updateColumn, deleteColumn, setColumns,
    addRow, updateRow, deleteRow, setRows
  } = useTableStore();

  // Dark Mode Sync
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);


  // Fetch server status on mount
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const res = await fetch("/api/config");
        const data = await res.json();
        setGeminiConfigured(data.gemini_configured);
        setAppUrl(data.app_url);
      } catch (e) {}
    };
    fetchConfig();
  }, [setGeminiConfigured, setAppUrl]);

  // Authenticate user to sync to Firebase (Lazy Loaded to avoid early initializeup penalty)
  useEffect(() => {
    let unsubscribe: any;
    let isCancelled = false;
    
    // Defer firebase initialization by 200ms to prioritize First Paint and load extremely fast
    const timer = setTimeout(async () => {
      const fb = await lazyInitFirebase();
      if (isCancelled) return;
      unsubscribe = fb.initAuth((user: any) => {
        setUserId(user.uid);
      }, () => {
        setUserId(null);
      });
    }, 200);

    return () => { 
      isCancelled = true;
      clearTimeout(timer);
      if (typeof unsubscribe === 'function') unsubscribe(); 
    };
  }, [setUserId]);

  // Sync transport format to Dynamic Table layout
  const syncBookingsToTable = (bookingData: Booking[]) => {
    setCustomTables(
      customTables.map(t => {
        if (t.id === "transport_bookings") {
          return { ...t, rows: bookingData as unknown as TableRow[] };
        }
        return t;
      }),
      true
    );
  };

  useEffect(() => {
    let unsubscribe: any;
    let isCancelled = false;

    if (userId) {
      lazyInitFirebase().then((fb) => {
        if (isCancelled) return;
        unsubscribe = fb.subscribeToBookings((data: any) => {
          if (isCancelled) return;
          if (data.length > 0) {
            setCustomTables(useTableStore.getState().customTables.map(t => 
              t.id === "transport_bookings" ? { ...t, rows: data as unknown as TableRow[] } : t
            ), true);
          } else {
            setCustomTables(useTableStore.getState().customTables.map(t => 
              t.id === "transport_bookings" ? { ...t, rows: [] } : t
            ), true);
          }
        });
      });
      return () => { 
        isCancelled = true;
        if (typeof unsubscribe === 'function') unsubscribe(); 
      }
    } else {
      const saved = localStorage.getItem("transport_ai_custom_tables");
      if (saved) {
        try {
          const loadedTables = JSON.parse(saved);
          setCustomTables(loadedTables, true);
        } catch (e) {}
      } else {
        localStorage.setItem("transport_ai_custom_tables", JSON.stringify(customTables));
      }
    }
  }, [userId, setCustomTables]); // remove customTables from dep array to avoid repeated calls

  // Helper for UI statistics (always operates on transport_bookings)
  const { totalBookings, pendingCount, dispatchCount, totalEarningsVal } = React.useMemo(() => {
    const transportTable = customTables.find(t => t.id === "transport_bookings");
    const tRows = transportTable?.rows || [];
    const totalBookings = tRows.length;
    const pendingCount = tRows.filter((b: any) => b.status === "Pending").length;
    const dispatchCount = tRows.filter((b: any) => b.status === "Dispatched").length;
    const totalEarningsVal = tRows
      .filter((b: any) => b.status !== "Cancelled")
      .reduce((sum: number, b: any) => {
        const cleanRate = String(b.rate || "").replace(/,/g, "").replace(/₹/g, "").trim();
        const num = Number(cleanRate);
        return sum + (isNaN(num) ? 0 : num);
      }, 0);
    return { totalBookings, pendingCount, dispatchCount, totalEarningsVal };
  }, [customTables]);

  return (
    <div className="min-h-screen bg-slate-50/70 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans antialiased transition-colors">
      <Sidebar />
      <Header geminiConfigured={geminiConfigured} appUrl={appUrl} userId={userId} />

      <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 w-full max-w-7xl mx-auto flex flex-col">
        {activeTab === "dashboard" && (
            <div className="flex flex-col gap-6 animate-fadeIn">
              {/* Bento Grid Analytics Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/50 hover:border-slate-300 p-4.5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.01)] transition select-none">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono">
                      Active Bookings
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-slate-850 dark:text-slate-100 tracking-tight">{totalBookings}</span>
                  </div>
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/50 hover:border-slate-300 p-4.5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.01)] transition select-none">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono">
                      Pending Operations
                    </span>
                    <Clock className="w-4 h-4 text-amber-500" />
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-slate-850 dark:text-slate-100 tracking-tight">{pendingCount}</span>
                  </div>
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/50 hover:border-slate-300 p-4.5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.01)] transition select-none">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono">
                      Dispatched Cargo
                    </span>
                    <CheckCircle className="w-4 h-4 text-sky-500" />
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-slate-850 dark:text-slate-100 tracking-tight">{dispatchCount}</span>
                  </div>
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/50 hover:border-slate-300 p-4.5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.01)] transition select-none">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono">
                      Pipeline Value (INR)
                    </span>
                    <DollarSign className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-slate-850 dark:text-slate-100 tracking-tight">₹{totalEarningsVal.toLocaleString("en-IN")}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col">
                <Suspense fallback={
                  <div className="flex-1 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/50 h-[750px] animate-pulse"></div>
                }>
                  <ChatSimulator geminiConfigured={geminiConfigured} />
                </Suspense>
              </div>
            </div>
          )}

          <div className="flex-1 flex flex-col">
            <Suspense fallback={
              <div className="flex-1 flex flex-col gap-4 animate-pulse">
               <div className="h-10 w-full md:w-1/3 bg-slate-200 dark:bg-slate-800 rounded-lg"></div>
               <div className="flex-1 rounded-2xl bg-white/50 dark:bg-slate-900/50 border border-slate-200/50 dark:border-slate-800/50 min-h-[500px]"></div>
              </div>
            }>
              {activeTab === "bookings" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <DynamicSheetDatabase />
                </div>
              )}

              {activeTab === "parties" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <PartyManagement />
                </div>
              )}

              {activeTab === "setup" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <SetupGuide />
                </div>
              )}

              {activeTab === "drivers" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <DriverManagement />
                </div>
              )}
              {activeTab === "vehicles" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <VehicleManagement />
                </div>
              )}
              {activeTab === "mechanics" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <MechanicManagement />
                </div>
              )}
              {activeTab === "payments" && <PlaceholderModule title="Payments Engine" description="Process freight invoicing, vendor payouts, and automate delayed payment alerts." />}
              {activeTab === "expenses" && <PlaceholderModule title="Expense Tracking" description="AI-powered receipt scanning and expense categorization for trip-level spend." />}
              {activeTab === "dispatch" && <PlaceholderModule title="Dispatch & Fulfillment" description="Assign drivers to loads intelligently via predictive AI routing." />}
              {activeTab === "tracking" && <PlaceholderModule title="Live Trip Tracking" description="GPS integrations providing real-time ETA predictions to customers." />}
              {activeTab === "ledger" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <LedgerManagement />
                </div>
              )}
              {activeTab === "webhooks" && (
                <div className="flex flex-col gap-5 h-full animate-fadeIn pb-6">
                  <WebhookViewer />
                </div>
              )}
              {activeTab === "automations" && <PlaceholderModule title="Workflow Automations" description="Visual builder to connect AI intent outputs to external webhooks and internal updates." />}
            </Suspense>
          </div>
        </main>
    </div>
  );
}

