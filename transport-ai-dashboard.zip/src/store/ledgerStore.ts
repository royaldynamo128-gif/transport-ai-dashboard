import { create } from 'zustand';
import { LedgerTransaction } from '../types';

interface LedgerState {
  transactions: LedgerTransaction[];
  
  // Actions
  addTransaction: (transaction: LedgerTransaction) => void;
  // Note: Standard double-entry or immutable ledger shouldn't expose 'update' or 'delete' easily, 
  // but for a React local store prototypes we might need them or reversal actions.
}

const MOCK_TRANSACTIONS: LedgerTransaction[] = [
  {
    id: "tx1",
    type: "DRIVER_ADVANCE",
    amount: 5000,
    date: new Date().toISOString(),
    driverId: "d1",
    paymentMethod: "Cash",
    remarks: "Advance for Delhi trip"
  }
];

export const useLedgerStore = create<LedgerState>((set) => ({
  transactions: MOCK_TRANSACTIONS,
  
  addTransaction: (transaction) => set((state) => ({ 
    transactions: [...state.transactions, transaction] 
  })),
}));
