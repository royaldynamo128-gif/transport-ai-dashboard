import { create } from 'zustand';
import { CustomTable, TableColumn, TableRow } from '../types';
import { TRANSPORT_COLUMNS, OTHER_DEFAULT_TABLES } from '../config/constants';
import { useUiStore } from './uiStore';

// Lazy Load Firebase to avoid heavy boot inside store
let firebaseLazy: any = null;
const lazyInitFirebase = async () => {
  if (!firebaseLazy) {
    const fb = await import("../services/firebase");
    const bg = await import("../services/bookings");
    firebaseLazy = { ...fb, ...bg };
  }
  return firebaseLazy;
};

interface TableState {
  customTables: CustomTable[];
  activeTableId: string;
  setCustomTables: (tables: CustomTable[], skipHistory?: boolean) => void;
  setActiveTableId: (id: string) => void;
  addTable: (table: CustomTable) => void;
  updateTable: (id: string, updates: Partial<CustomTable>) => void;
  addColumn: (tableId: string, column: TableColumn) => void;
  updateColumn: (tableId: string, colId: string, updates: Partial<TableColumn>) => void;
  deleteColumn: (tableId: string, colId: string) => void;
  setColumns: (tableId: string, columns: TableColumn[]) => void;
  addRow: (tableId: string, row: TableRow) => void;
  updateRow: (tableId: string, rowId: string, updates: Partial<TableRow>) => void;
  deleteRow: (tableId: string, rowId: string) => void;
  setRows: (tableId: string, rows: TableRow[]) => void;
  
  // High-level Actions to replace prop drilling
  handleUpdateColumns: (tableId: string, newColumns: TableColumn[]) => void;
  handleDeleteTableColumn: (tableId: string, columnId: string) => void;
  handleCreateTable: (name: string, customCols?: TableColumn[]) => void;
  handleRenameTable: (tableId: string, newName: string) => void;
  handleDuplicateTableSchema: (tableId: string, newName: string) => void;
  handleAddRow: (tableId: string, row: Record<string, any>) => Promise<void>;
  handleUpdateRow: (tableId: string, rowId: string, updates: Record<string, any>) => Promise<void>;
  handleImportData: (tableId: string, columns: TableColumn[], rows: TableRow[]) => Promise<void>;
  handleDeleteRow: (tableId: string, rowId: string) => Promise<void>;
  handleDeleteSelectedRows: (tableId: string, rowIds: string[]) => Promise<void>;
  handleDeleteSelectedColumns: (tableId: string, colIds: string[]) => void;
  handleClearSelectedCells: (tableId: string, rowIds: string[], colIds: string[]) => void;
  history: CustomTable[][];
  historyIndex: number;
  lastAction: string | null;
  clearLastAction: () => void;
  undo: () => void;
  redo: () => void;
  saveLocalTables: (tables: CustomTable[], skipHistory?: boolean, actionName?: string) => void;
}

const DEMO_BOOKINGS = [
  { id: "BK08429155", timestamp: "21-May-2026 03:22 PM", customer: "Tata Steel", pickup: "Delhi", destination: "Pune", material: "Iron Rods", weight: "25 Ton", truckType: "Trailer (Open)", rate: "45000", status: "Confirmed", source: "via WhatsApp" },
  { id: "BK08429582", timestamp: "21-May-2026 05:40 PM", customer: "Birla Cement Ltd", pickup: "Mumbai", destination: "Bangalore", material: "Cement Bags", weight: "15 Ton", truckType: "Taurus (10 Wheel)", rate: "36000", status: "Pending", source: "via WhatsApp" },
];

export const useTableStore = create<TableState>((set, get) => {
  const initialTables = [
    {
      id: "transport_bookings",
      name: "Transport Bookings (Live)",
      columns: TRANSPORT_COLUMNS,
      rows: DEMO_BOOKINGS as unknown as TableRow[]
    },
    ...OTHER_DEFAULT_TABLES
  ];

  return {
    customTables: initialTables,
    activeTableId: "transport_bookings",
    history: [initialTables],
    historyIndex: 0,
    lastAction: null,
    clearLastAction: () => set({ lastAction: null }),
    undo: () => {
      const { history, historyIndex } = get();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        const previousState = history[newIndex];
        set({ customTables: previousState, historyIndex: newIndex, lastAction: "Action undone" });
        localStorage.setItem("transport_ai_custom_tables", JSON.stringify(previousState));
      }
    },
    redo: () => {
      const { history, historyIndex } = get();
      if (historyIndex < history.length - 1) {
        const newIndex = historyIndex + 1;
        const nextState = history[newIndex];
        set({ customTables: nextState, historyIndex: newIndex, lastAction: "Action redone" });
        localStorage.setItem("transport_ai_custom_tables", JSON.stringify(nextState));
      }
    },
    setCustomTables: (tables, skipHistory) => {
      get().saveLocalTables(tables, skipHistory);
    },
    setActiveTableId: (id) => set({ activeTableId: id }),
  addTable: (table) => set((state) => ({ customTables: [...state.customTables, table] })),
  updateTable: (id, updates) => set((state) => ({
    customTables: state.customTables.map((t) => (t.id === id ? { ...t, ...updates } : t)),
  })),
  addColumn: (tableId, column) => set((state) => ({
    customTables: state.customTables.map((t) => (t.id === tableId ? { ...t, columns: [...t.columns, column] } : t)),
  })),
  updateColumn: (tableId, colId, updates) => set((state) => ({
    customTables: state.customTables.map((t) => {
      if (t.id === tableId) {
        return { ...t, columns: t.columns.map((c) => (c.id === colId ? { ...c, ...updates } : c)) };
      }
      return t;
    }),
  })),
  deleteColumn: (tableId, colId) => set((state) => ({
    customTables: state.customTables.map((t) => {
      if (t.id === tableId) {
        return { ...t, columns: t.columns.filter((c) => c.id !== colId) };
      }
      return t;
    }),
  })),
  setColumns: (tableId, columns) => set((state) => ({
    customTables: state.customTables.map((t) => (t.id === tableId ? { ...t, columns } : t)),
  })),
  addRow: (tableId, row) => set((state) => ({
    customTables: state.customTables.map((t) => {
      if (t.id === tableId) {
        return { ...t, rows: [row, ...t.rows] };
      }
      return t;
    }),
  })),
  updateRow: (tableId, rowId, updates) => set((state) => ({
    customTables: state.customTables.map((t) => {
      if (t.id === tableId) {
        return { ...t, rows: t.rows.map((r) => (r.id === rowId ? { ...r, ...updates } : r)) };
      }
      return t;
    }),
  })),
  deleteRow: (tableId, rowId) => set((state) => ({
    customTables: state.customTables.map((t) => {
      if (t.id === tableId) {
        return { ...t, rows: t.rows.filter((r) => r.id !== rowId) };
      }
      return t;
    }),
  })),
  setRows: (tableId, rows) => set((state) => ({
    customTables: state.customTables.map((t) => (t.id === tableId ? { ...t, rows } : t)),
  })),

  // High level actions
  saveLocalTables: (tables: CustomTable[], skipHistory?: boolean, actionName?: string) => {
    if (skipHistory) {
      set({ customTables: tables });
    } else {
      const { history, historyIndex } = get();
      // Throw away future history if we're making a new change after undo
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(tables);
      // Optional: Limit history length to e.g. 50
      if (newHistory.length > 50) newHistory.shift();
      
      set({ 
        customTables: tables, 
        history: newHistory,
        historyIndex: newHistory.length - 1,
        lastAction: actionName || "Changes saved"
      });
    }

    // Optimize localStorage writes: Defer to prevent input lag, and strip live rows to keep it microscopic!
    setTimeout(() => {
      const userId = useUiStore.getState().userId;
      const tablesToStore = tables.map(t => {
        if (t.id === "transport_bookings" && userId) {
          return { ...t, rows: [] };
        }
        return t;
      });
      localStorage.setItem("transport_ai_custom_tables", JSON.stringify(tablesToStore));
    }, 0);
  },

  handleUpdateColumns: (tableId: string, newColumns: TableColumn[]) => {
    const next = get().customTables.map(t => t.id === tableId ? { ...t, columns: newColumns } : t);
    get().saveLocalTables(next, false, "Columns updated");
  },

  handleDeleteTableColumn: (tableId: string, columnId: string) => {
    const next = get().customTables.map(t => {
      if (t.id === tableId) {
        return { ...t, columns: t.columns.filter((c: any) => c.id !== columnId) };
      }
      return t;
    });
    get().saveLocalTables(next, false, "Column deleted");
  },

  handleCreateTable: (name: string, customCols?: TableColumn[]) => {
    const next = [...get().customTables, { id: `table_${Date.now()}`, name, columns: customCols || [{id: "col_1", name: "Column 1", type: "text"}], rows: [] as TableRow[] }];
    set({ activeTableId: next[next.length - 1].id });
    get().saveLocalTables(next, false, "Table created");
  },

  handleRenameTable: (tableId: string, newName: string) => {
    const next = get().customTables.map(t => t.id === tableId ? { ...t, name: newName } : t);
    get().saveLocalTables(next, false, "Table renamed");
  },

  handleDuplicateTableSchema: (tableId: string, newName: string) => {
    const sourceTable = get().customTables.find(t => t.id === tableId);
    if (!sourceTable) return;
    get().handleCreateTable(newName, sourceTable.columns);
  },

  handleAddRow: async (tableId: string, row: Record<string, any>) => {
    const userId = useUiStore.getState().userId;
    if (tableId === "transport_bookings" && userId) {
      const fb = await lazyInitFirebase();
      await fb.addBooking(row as any);
    } else {
      const next = get().customTables.map(t => t.id === tableId ? { ...t, rows: [row as TableRow, ...t.rows] } : t);
      get().saveLocalTables(next, false, "Row added");
    }
  },

  handleUpdateRow: async (tableId: string, rowId: string, updates: Record<string, any>) => {
    const userId = useUiStore.getState().userId;
    if (tableId === "transport_bookings" && userId) {
      const fb = await lazyInitFirebase();
      await fb.updateBooking(rowId, updates);
    } else {
      const next = get().customTables.map(t => {
        if (t.id === tableId) {
          return { ...t, rows: t.rows.map(r => r.id === rowId ? { ...r, ...updates } : r) };
        }
        return t;
      });
      get().saveLocalTables(next, false, "Row updated");
    }
  },

  handleImportData: async (tableId: string, columns: TableColumn[], rows: TableRow[]) => {
    const next = get().customTables.map(t => {
      if (t.id === tableId) {
        return { ...t, columns, rows };
      }
      return t;
    });
    get().saveLocalTables(next, false, "Data imported");
  },

  handleDeleteRow: async (tableId: string, rowId: string) => {
    const userId = useUiStore.getState().userId;
    if (tableId === "transport_bookings" && userId) {
      const fb = await lazyInitFirebase();
      await fb.deleteBooking(rowId);
    } else {
      const next = get().customTables.map(t => {
        if (t.id === tableId) {
          return { ...t, rows: t.rows.filter(r => r.id !== rowId) };
        }
        return t;
      });
      get().saveLocalTables(next, false, "Row deleted");
    }
  },

  handleDeleteSelectedRows: async (tableId: string, rowIds: string[]) => {
    const userId = useUiStore.getState().userId;
    if (tableId === "transport_bookings" && userId) {
      const fb = await lazyInitFirebase();
      // Need to delete multiple from firebase, loop or batch
      for (const rowId of rowIds) {
        await fb.deleteBooking(rowId);
      }
    } else {
      const next = get().customTables.map(t => {
        if (t.id === tableId) {
          return { ...t, rows: t.rows.filter(r => !rowIds.includes(r.id)) };
        }
        return t;
      });
      get().saveLocalTables(next, false, `${rowIds.length} rows deleted`);
    }
  },

  handleDeleteSelectedColumns: (tableId: string, colIds: string[]) => {
    const next = get().customTables.map(t => {
      if (t.id === tableId) {
        return { ...t, columns: t.columns.filter((c: any) => !colIds.includes(c.id)) };
      }
      return t;
    });
    get().saveLocalTables(next, false, `${colIds.length} columns deleted`);
  },

  handleClearSelectedCells: (tableId: string, rowIds: string[], colIds: string[]) => {
    const next = get().customTables.map(t => {
      if (t.id === tableId) {
        return {
          ...t,
          rows: t.rows.map(r => {
            if (rowIds.includes(r.id)) {
              const newRow = { ...r };
              for (const c of colIds) {
                newRow[c] = "";
              }
              return newRow as TableRow;
            }
            return r;
          })
        };
      }
      return t;
    });
    get().saveLocalTables(next, false, "Cells cleared");
  }
};
});
