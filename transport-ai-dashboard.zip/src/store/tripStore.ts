import { create } from 'zustand';
import { Trip } from '../types';

interface TripState {
  trips: Trip[];
  selectedTripId: string | null;
  
  setTrips: (trips: Trip[]) => void;
  addTrip: (trip: Trip) => void;
  updateTrip: (id: string, updates: Partial<Trip>) => void;
  deleteTrip: (id: string) => void;
  setSelectedTrip: (id: string | null) => void;
}

const MOCK_TRIPS: Trip[] = [
  {
    id: "t1",
    bookingDate: new Date().toISOString(),
    partyId: "p1", // References Rammurti Transport Company
    driverId: "d1", // References Ramesh Singh
    vehicleId: "v1", // References HR-38-Z-1234
    pickupLocation: "Delhi",
    dropLocation: "Mumbai",
    materialDescription: "Electronics",
    weight: "8 MT",
    freightAmount: 85000,
    advanceGiven: 5000,
    bilibiltyStatus: "Pending",
    status: "In Transit",
    documents: [],
    extraNotes: "Handle with extra care. Needs immediate unloading on arrival."
  }
];

export const useTripStore = create<TripState>((set) => ({
  trips: MOCK_TRIPS,
  selectedTripId: null,
  
  setTrips: (trips) => set({ trips }),
  
  addTrip: (trip) => set((state) => ({ 
    trips: [...state.trips, trip] 
  })),
  
  updateTrip: (id, updates) => set((state) => ({
    trips: state.trips.map((t) => (t.id === id ? { ...t, ...updates } : t))
  })),
  
  deleteTrip: (id) => set((state) => ({
    trips: state.trips.filter((t) => t.id !== id)
  })),
  
  setSelectedTrip: (id) => set({ selectedTripId: id }),
}));
