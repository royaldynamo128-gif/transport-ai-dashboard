import { create } from 'zustand';

interface ExtensionState {
  activeExtensions: string[];
  setActiveExtensions: (exts: string[]) => void;
  extensionConfigs: Record<string, any>;
  setExtensionConfig: (id: string, config: any) => void;
  // Could hold modal states for extensions
  isExtensionsModalOpen: boolean;
  setIsExtensionsModalOpen: (isOpen: boolean) => void;
}

export const useExtensionStore = create<ExtensionState>((set) => ({
  activeExtensions: [],
  setActiveExtensions: (exts) => set({ activeExtensions: exts }),
  extensionConfigs: {},
  setExtensionConfig: (id, config) => set((state) => ({
    extensionConfigs: { ...state.extensionConfigs, [id]: config }
  })),
  isExtensionsModalOpen: false,
  setIsExtensionsModalOpen: (isOpen) => set({ isExtensionsModalOpen: isOpen }),
}));
