import { create } from 'zustand';
import { Party } from '../types';

interface PartyState {
  parties: Party[];
  selectedPartyId: string | null;
  
  // Actions
  setParties: (parties: Party[]) => void;
  addParty: (party: Party) => void;
  updateParty: (id: string, updates: Partial<Party>) => void;
  deleteParty: (id: string) => void;
  setSelectedParty: (id: string | null) => void;
}

// Sample initial data for testing
const MOCK_PARTIES: Party[] = [
  {
    id: "p1",
    name: "Rammurti Transport Company",
    phone: "9876543210",
    contactPerson: "Rajesh Kumar",
    address: "Transport Nagar, Delhi",
    cachedOutstandingBalance: 15000, 
    status: "Active",
    documents: [],
    extraNotes: "Prefers payment on 15th of every month."
  }
];

export const usePartyStore = create<PartyState>((set) => ({
  parties: MOCK_PARTIES, // Start with mock data to make UI building easier later
  selectedPartyId: null,
  
  setParties: (parties) => set({ parties }),
  
  addParty: (party) => set((state) => ({ 
    parties: [...state.parties, party] 
  })),
  
  updateParty: (id, updates) => set((state) => ({
    parties: state.parties.map((p) => (p.id === id ? { ...p, ...updates } : p))
  })),
  
  deleteParty: (id) => set((state) => ({
    parties: state.parties.filter((p) => p.id !== id)
  })),
  
  setSelectedParty: (id) => set({ selectedPartyId: id }),
}));
