import { create } from 'zustand';

interface PaymentState {
  payments: any[];
  setPayments: (payments: any[]) => void;
  isLoading: boolean;
  setIsLoading: (isLoading: boolean) => void;
}

export const usePaymentStore = create<PaymentState>((set) => ({
  payments: [],
  setPayments: (payments) => set({ payments }),
  isLoading: false,
  setIsLoading: (isLoading) => set({ isLoading }),
}));
