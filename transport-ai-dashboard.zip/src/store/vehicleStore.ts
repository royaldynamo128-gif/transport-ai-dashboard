import { create } from 'zustand';
import { Vehicle } from '../types';

interface VehicleState {
  vehicles: Vehicle[];
  selectedVehicleId: string | null;
  
  setVehicles: (vehicles: Vehicle[]) => void;
  addVehicle: (vehicle: Vehicle) => void;
  updateVehicle: (id: string, updates: Partial<Vehicle>) => void;
  deleteVehicle: (id: string) => void;
  setSelectedVehicle: (id: string | null) => void;
}

const MOCK_VEHICLES: Vehicle[] = [
  {
    id: "v1",
    registrationNumber: "HR-38-Z-1234",
    type: "Open Body",
    capacity: "20 MT",
    status: "Available",
    documents: [],
    extraNotes: "Requires battery check soon."
  }
];

export const useVehicleStore = create<VehicleState>((set) => ({
  vehicles: MOCK_VEHICLES,
  selectedVehicleId: null,
  
  setVehicles: (vehicles) => set({ vehicles }),
  
  addVehicle: (vehicle) => set((state) => ({ 
    vehicles: [...state.vehicles, vehicle] 
  })),
  
  updateVehicle: (id, updates) => set((state) => ({
    vehicles: state.vehicles.map((v) => (v.id === id ? { ...v, ...updates } : v))
  })),
  
  deleteVehicle: (id) => set((state) => ({
    vehicles: state.vehicles.filter((v) => v.id !== id)
  })),
  
  setSelectedVehicle: (id) => set({ selectedVehicleId: id }),
}));
