import { create } from 'zustand';
import { ChatMessage } from '../types';

export interface AiState {
  messages: ChatMessage[];
  setMessages: (messages: ChatMessage[] | ((prev: ChatMessage[]) => ChatMessage[])) => void;
  inputText: string;
  setInputText: (text: string) => void;
  isTyping: boolean;
  setIsTyping: (isTyping: boolean) => void;
  activeExtraction: any | null;
  setActiveExtraction: (data: any) => void;
  aiEnginePayload: any | null;
  setAiEnginePayload: (data: any) => void;
  lastApiMode: string;
  setLastApiMode: (mode: string) => void;
  extractionResponseTime: number | null;
  setExtractionResponseTime: (time: number | null) => void;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: "init-1",
    sender: "bot",
    text: "👋 Hello! I am your AI-native Transport ERP Assistant.\n\nI can help you:\n- Extract details for bookings, trucks, and dispatch automatically.\n- Intelligently interact with tables and smart column extensions.\n- Handle natural language requests like 'Show pending bookings' or 'Assign nearest truck'.\n\nTry sending a message in English or Hinglish, and I'll process it into the correct database format effortlessly!",
    timestamp: "10:59 AM"
  }
];

export const useAiStore = create<AiState>((set) => ({
  messages: INITIAL_MESSAGES,
  setMessages: (updater) => set((state) => ({
    messages: typeof updater === 'function' ? updater(state.messages) : updater
  })),
  inputText: "",
  setInputText: (text) => set({ inputText: text }),
  isTyping: false,
  setIsTyping: (isTyping) => set({ isTyping: isTyping }),
  activeExtraction: null,
  setActiveExtraction: (data) => set({ activeExtraction: data }),
  aiEnginePayload: null,
  setAiEnginePayload: (data) => set({ aiEnginePayload: data }),
  lastApiMode: "",
  setLastApiMode: (mode) => set({ lastApiMode: mode }),
  extractionResponseTime: null,
  setExtractionResponseTime: (time) => set({ extractionResponseTime: time }),
}));
