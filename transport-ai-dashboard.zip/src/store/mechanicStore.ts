import { create } from 'zustand';
import { Mechanic } from '../types';

interface MechanicState {
  mechanics: Mechanic[];
  selectedMechanicId: string | null;
  
  setMechanics: (mechanics: Mechanic[]) => void;
  addMechanic: (mechanic: Mechanic) => void;
  updateMechanic: (id: string, updates: Partial<Mechanic>) => void;
  deleteMechanic: (id: string) => void;
  setSelectedMechanic: (id: string | null) => void;
}

const MOCK_MECHANICS: Mechanic[] = [
  {
    id: "m1",
    name: "Raju Ustad",
    phone: "9876543212",
    specialization: "Engine & Tyre",
    status: "Active",
    documents: [],
    extraNotes: "Only accepts cash payments."
  }
];

export const useMechanicStore = create<MechanicState>((set) => ({
  mechanics: MOCK_MECHANICS,
  selectedMechanicId: null,
  
  setMechanics: (mechanics) => set({ mechanics }),
  
  addMechanic: (mechanic) => set((state) => ({ 
    mechanics: [...state.mechanics, mechanic] 
  })),
  
  updateMechanic: (id, updates) => set((state) => ({
    mechanics: state.mechanics.map((m) => (m.id === id ? { ...m, ...updates } : m))
  })),
  
  deleteMechanic: (id) => set((state) => ({
    mechanics: state.mechanics.filter((m) => m.id !== id)
  })),
  
  setSelectedMechanic: (id) => set({ selectedMechanicId: id }),
}));
