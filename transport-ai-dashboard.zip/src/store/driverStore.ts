import { create } from 'zustand';
import { Driver } from '../types';

interface DriverState {
  drivers: Driver[];
  selectedDriverId: string | null;
  
  // Actions
  setDrivers: (drivers: Driver[]) => void;
  addDriver: (driver: Driver) => void;
  updateDriver: (id: string, updates: Partial<Driver>) => void;
  deleteDriver: (id: string) => void;
  setSelectedDriver: (id: string | null) => void;
}

const MOCK_DRIVERS: Driver[] = [
  {
    id: "d1",
    name: "Ramesh Singh",
    phone: "9876543211",
    licenseNumber: "DL-14-2020-0987",
    cachedAdvanceBalance: 5000,
    status: "Active",
    documents: [],
    extraNotes: "Takes frequent leaves on Mondays."
  }
];

export const useDriverStore = create<DriverState>((set) => ({
  drivers: MOCK_DRIVERS,
  selectedDriverId: null,
  
  setDrivers: (drivers) => set({ drivers }),
  
  addDriver: (driver) => set((state) => ({ 
    drivers: [...state.drivers, driver] 
  })),
  
  updateDriver: (id, updates) => set((state) => ({
    drivers: state.drivers.map((d) => (d.id === id ? { ...d, ...updates } : d))
  })),
  
  deleteDriver: (id) => set((state) => ({
    drivers: state.drivers.filter((d) => d.id !== id)
  })),
  
  setSelectedDriver: (id) => set({ selectedDriverId: id }),
}));
