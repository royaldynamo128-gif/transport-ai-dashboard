import { create } from 'zustand';

type TabType = "dashboard" | "bookings" | "parties" | "drivers" | "vehicles" | "mechanics" | "payments" | "expenses" | "dispatch" | "tracking" | "ledger" | "ai" | "automations" | "webhooks" | "setup";

export interface AppModalConfig {
  isOpen?: boolean;
  type?: 'prompt' | 'confirm';
  title?: string;
  message?: string;
  inputValue?: string;
  onConfirm?: (val?: string) => void;
}

interface UiState {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (isOpen: boolean) => void;
  geminiConfigured: boolean;
  setGeminiConfigured: (configured: boolean) => void;
  appUrl: string;
  setAppUrl: (url: string) => void;
  userId: string | null;
  setUserId: (id: string | null) => void;
  isDarkMode: boolean;
  setIsDarkMode: (isDark: boolean) => void;
  
  // Modals state
  appModalConfig: AppModalConfig;
  setAppModalConfig: (config: AppModalConfig) => void;
  openAppModal: (config: Omit<AppModalConfig, 'isOpen'>) => void;
  closeAppModal: () => void;
}

export const useUiStore = create<UiState>((set) => ({
  activeTab: "dashboard",
  setActiveTab: (tab) => set({ activeTab: tab }),
  isSidebarOpen: false,
  setIsSidebarOpen: (isOpen) => set({ isSidebarOpen: isOpen }),
  geminiConfigured: false,
  setGeminiConfigured: (configured) => set({ geminiConfigured: configured }),
  appUrl: "http://localhost:3000",
  setAppUrl: (url) => set({ appUrl: url }),
  userId: null,
  setUserId: (id) => set({ userId: id }),
  isDarkMode: (() => {
    if (typeof localStorage !== 'undefined') {
      const stored = localStorage.getItem("transport_ai_theme");
      if (stored !== null) {
        return stored === "dark";
      }
    }
    return true; // Default to dark mode
  })(),
  setIsDarkMode: (isDark) => {
    localStorage.setItem("transport_ai_theme", isDark ? "dark" : "light");
    set({ isDarkMode: isDark });
  },

  appModalConfig: { isOpen: false, type: 'prompt', title: '' },
  setAppModalConfig: (config) => set({ appModalConfig: config }),
  openAppModal: (config) => set((state) => ({ 
    appModalConfig: { ...state.appModalConfig, ...config, isOpen: true, inputValue: config.type === 'prompt' ? config.inputValue || "" : "" } 
  })),
  closeAppModal: () => set((state) => ({
    appModalConfig: { ...state.appModalConfig, isOpen: false }
  })),
}));
