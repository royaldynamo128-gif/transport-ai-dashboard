import { create } from 'zustand';

interface BookingState {
  bookings: any[];
  setBookings: (bookings: any[]) => void;
  isLoading: boolean;
  setIsLoading: (isLoading: boolean) => void;
}

export const useBookingStore = create<BookingState>((set) => ({
  bookings: [],
  setBookings: (bookings) => set({ bookings }),
  isLoading: false,
  setIsLoading: (isLoading) => set({ isLoading }),
}));
