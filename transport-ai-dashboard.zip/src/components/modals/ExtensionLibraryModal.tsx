import React from 'react';
import { useTableStore } from '../../store/tableStore';
import { useExtensionStore } from '../../store/extensionStore';
import { useUiStore } from '../../store/uiStore';
import { 
  X, Zap, Blocks, Phone, MapPin, IndianRupee, 
  Calendar, User, Tag, Plus, Check, MessageCircle, AlertTriangle
} from 'lucide-react';
import { TableColumn } from '../../types';

export function ExtensionLibraryModal() {
  const { isExtensionsModalOpen, setIsExtensionsModalOpen } = useExtensionStore();
  const { customTables, activeTableId, handleUpdateColumns, handleDeleteTableColumn } = useTableStore();
  const { openAppModal } = useUiStore();

  if (!isExtensionsModalOpen) return null;

  const activeTable = customTables.find(t => t.id === activeTableId);
  if (!activeTable) return null;

  const activeExtensions = activeTable.columns.filter(c => c.type !== 'text');

  const availableExtensions = [
    { type: 'status', name: "Workflow Status", desc: "Color-coded shipment workflow badges.", icon: <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.5)]"></div>, color: "emerald" },
    { type: 'phone', name: "Contact Number", desc: "Clickable Call / SMS actions.", icon: <Phone className="w-5 h-5 text-purple-400" />, color: "purple" },
    { type: 'location', name: "Location Map", desc: "Maps integration and routing.", icon: <MapPin className="w-5 h-5 text-blue-400" />, color: "blue" },
    { type: 'driver', name: "Driver Assign", desc: "Driver assignment & vehicle linking.", icon: <User className="w-5 h-5 text-purple-500" />, color: "purple" },
    { type: 'money', name: "Money / Rates", desc: "Currency formatting & auto-calculations.", icon: <IndianRupee className="w-5 h-5 text-emerald-400" />, color: "emerald" },
    { type: 'date', name: "Timeline Date", desc: "Calendar picker and logistics timeline.", icon: <Calendar className="w-5 h-5 text-blue-500" />, color: "blue" },
    { type: 'number', name: "Number Format", desc: "Numeric validation and metrics.", icon: <span className="font-mono font-bold text-lg text-purple-300">#</span>, color: "purple" },
    { type: 'tags', name: "Category Tags", desc: "Multi-label shipment categorization.", icon: <Tag className="w-5 h-5 text-indigo-400" />, color: "indigo" }
  ] as const;

  const handleAddExtension = (ext: typeof availableExtensions[number]) => {
    const existingCount = activeTable.columns.filter(c => c.type === ext.type).length;
    const suffix = existingCount > 0 ? ` ${existingCount + 1}` : '';
    const newName = `${ext.name}${suffix}`;
    const newCols = [...activeTable.columns, { id: `col_${Date.now()}`, name: newName, type: ext.type as TableColumn['type'] }];
    handleUpdateColumns(activeTable.id, newCols);
  };

  const handleDisableExtension = (colId: string) => {
    // Treat "Disable" as making it a classic text column for now
    const newCols = activeTable.columns.map(c => c.id === colId ? { ...c, type: 'text' as const } : c);
    handleUpdateColumns(activeTable.id, newCols);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="absolute inset-0 bg-black/80 sm:backdrop-blur-sm" 
        onClick={() => setIsExtensionsModalOpen(false)} 
      />
      
      <div className="relative bg-slate-900 border border-indigo-500/20 shadow-2xl rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden text-slate-200">
        
        {/* Glow Effects */}
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent"></div>
        <div className="absolute -top-[100px] -left-[100px] w-64 h-64 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-500/15 to-transparent rounded-full pointer-events-none"></div>
        <div className="absolute -bottom-[100px] -right-[100px] w-64 h-64 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-500/15 to-transparent rounded-full pointer-events-none"></div>

        {/* Header */}
        <div className="px-6 py-5 flex items-center justify-between border-b border-white/5 bg-white/5 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center relative overflow-hidden shadow-[0_0_20px_rgba(168,85,247,0.3)]">
               <Zap className="w-6 h-6 text-purple-400 fill-purple-400/30" />
            </div>
            <div>
              <h2 className="text-xl font-bold bg-gradient-to-r from-blue-300 to-purple-400 bg-clip-text text-transparent leading-tight">
                Extension Library
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Augment your active tables with smart block extensions</p>
            </div>
          </div>
          <button 
            onClick={() => setIsExtensionsModalOpen(false)}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 relative z-10 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {availableExtensions.map((ext) => {
              const activeCount = activeTable.columns.filter(c => c.type === ext.type).length;
              const isActive = activeCount > 0;
              
              return (
                <div 
                  key={ext.type} 
                  className={`group relative flex flex-col bg-slate-800/50 rounded-2xl border p-5 transition-all duration-305 overflow-hidden ${
                    isActive 
                      ? "border-purple-500/40 shadow-[0_4px_20px_rgba(168,85,247,0.1)]" 
                      : "border-white/10 hover:border-blue-400/40 hover:shadow-[0_4px_20px_rgba(96,165,250,0.1)] hover:-translate-y-0.5"
                  }`}
                >
                  {/* Subtle top glare on hover */}
                  <div className="absolute top-0 inset-x-0 h-1/2 bg-gradient-to-b from-white/[0.03] to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  
                  <div className="flex items-start justify-between mb-4 relative z-10">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-black/20 border border-white/5 group-hover:scale-110 transition-transform duration-300">
                      {ext.icon}
                    </div>
                    
                    <div className="flex items-center gap-1.5">
                      {isActive && (
                        <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/20 shadow-sm">
                          {activeCount} Active
                        </span>
                      )}
                      
                      <button
                        onClick={() => handleAddExtension(ext)}
                        className={`text-[10px] uppercase tracking-wider font-bold px-2.5 py-1.5 rounded-md flex items-center gap-1 shadow-sm transition-all duration-200 ${
                          isActive 
                            ? "hover:bg-purple-500 hover:border-purple-400 text-slate-300 hover:text-white border border-white/10 bg-white/5 opacity-60 group-hover:opacity-100 cursor-pointer" 
                            : "opacity-0 group-hover:opacity-100 bg-blue-500 hover:bg-blue-400 text-white border border-transparent cursor-pointer"
                        }`}
                      >
                        <Plus className="w-3 h-3" /> Add{isActive ? " More" : ""}
                      </button>
                    </div>
                  </div>
                  <div className="relative z-10">
                    <h3 className="font-semibold text-slate-100 text-sm mb-1">{ext.name}</h3>
                    <p className="text-[11px] text-slate-400 leading-relaxed">{ext.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Extensions Management */}
          <div className="mt-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-1.5 h-4 bg-gradient-to-b from-blue-400 to-purple-500 rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)]"></div>
              <h3 className="text-sm font-bold tracking-wider uppercase bg-gradient-to-r from-blue-200 to-slate-300 bg-clip-text text-transparent">
                Active Configurations
              </h3>
            </div>
            
            <div className="bg-slate-800/40 border border-white/10 rounded-xl overflow-hidden">
              {activeExtensions.length === 0 ? (
                <div className="p-10 text-center text-slate-400 text-sm flex flex-col items-center justify-center">
                  <div className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mb-4 relative">
                    <Blocks className="w-7 h-7 text-slate-500" />
                    <div className="absolute inset-0 bg-white/5 blur-xl rounded-full"></div>
                  </div>
                  <p className="max-w-xs leading-relaxed">No smart extensions configured for this table. Click "Add" above to begin.</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5 list-none">
                  {activeExtensions.map((col) => {
                    const ExtIcon = availableExtensions.find(e => e.type === col.type)?.icon || <Blocks className="w-4 h-4 text-purple-400" />;
                    return (
                      <div key={col.id} className="flex items-center justify-between p-4 hover:bg-white/[0.03] transition-colors group">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-lg bg-black/20 flex items-center justify-center border border-white/5 shadow-inner">
                            {ExtIcon}
                          </div>
                          <div className="flex flex-col">
                            <div className="font-semibold text-sm text-slate-200">{col.name}</div>
                            <div className="text-[10px] text-purple-400/80 uppercase tracking-wider font-mono mt-0.5">Runtime: {col.type}</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => {
                              openAppModal({
                                type: 'prompt',
                                title: 'Rename Extension Column',
                                inputValue: col.name,
                                message: 'Provide a new display name for this active extension block.',
                                onConfirm: (val) => {
                                  if (val) {
                                    const newCols = activeTable.columns.map(c => c.id === col.id ? {...c, name: val} : c);
                                    handleUpdateColumns(activeTable.id, newCols);
                                  }
                                }
                              });
                              setIsExtensionsModalOpen(false);
                            }}
                            className="bg-white/5 hover:bg-blue-500/20 text-slate-300 hover:text-blue-300 border border-white/5 hover:border-blue-500/30 px-3 py-1.5 rounded-md text-[10px] uppercase font-bold tracking-wider flex items-center gap-1.5 transition-colors"
                          >
                            Edit
                          </button>
                          
                          <button
                            onClick={() => handleDisableExtension(col.id)}
                            className="bg-white/5 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 border border-white/5 hover:border-amber-500/30 px-3 py-1.5 rounded-md text-[10px] uppercase font-bold tracking-wider flex items-center gap-1.5 transition-colors"
                            title="Downgrade to plain text column"
                          >
                            Disable
                          </button>

                          <button
                            onClick={() => {
                              openAppModal({
                                type: 'confirm',
                                title: 'Delete Extension',
                                message: `Are you sure you want to completely remove the ${col.name} extension and all its data from this table?`,
                                onConfirm: () => handleDeleteTableColumn(activeTable.id, col.id)
                              });
                              setIsExtensionsModalOpen(false);
                            }}
                            className="bg-white/5 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400 border border-white/5 hover:border-rose-500/30 px-3 py-1.5 rounded-md text-[10px] uppercase font-bold tracking-wider flex items-center gap-1.5 transition-colors"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
