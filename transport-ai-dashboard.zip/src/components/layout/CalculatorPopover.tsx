import React, { useState, useEffect, useRef } from "react";
import { Calculator, Minimize2, Maximize2, X, Delete, GripHorizontal, Sliders } from "lucide-react";

export function CalculatorPopover() {
  const [isOpen, setIsOpen] = useState(false);
  
  // Size mode: 'compact' (just display/input + mini controls), 'regular' (standard mobile pad), 'pro' (fully expanded scientific/numeric pad)
  const [sizeMode, setSizeMode] = useState<'compact' | 'regular' | 'pro'>(() => {
    return (localStorage.getItem("transport_calc_sizemode") as any) || "regular";
  });

  const [expression, setExpression] = useState(() => {
    return localStorage.getItem("transport_calc_expression") || "";
  });
  const [result, setResult] = useState("");

  const popoverRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Position offset for dragging
  const [position, setPosition] = useState(() => {
    try {
      const saved = localStorage.getItem("transport_calc_position");
      return saved ? JSON.parse(saved) : { x: 0, y: 0 };
    } catch {
      return { x: 0, y: 0 };
    }
  });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });

  // Sync state to localstorage
  useEffect(() => {
    localStorage.setItem("transport_calc_sizemode", sizeMode);
  }, [sizeMode]);

  useEffect(() => {
    localStorage.setItem("transport_calc_expression", expression);
  }, [expression]);

  useEffect(() => {
    localStorage.setItem("transport_calc_position", JSON.stringify(position));
  }, [position]);

  // Handle outside click to close (optional - allow clicking around if they want to use it while typing, but let's close if they click outside the widget area)
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
        // If we want a true persistent floating window, we can optionally NOT close it on outside click, 
        // allowing the user to copy numbers to tables! Yes! This is a massive feature. 
        // Let's only close it if they explicitly close it, or click the trigger button.
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Dragging event handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    // Prevent dragging if user clicks buttons, input, or toggle selectors
    if (
      (e.target as HTMLElement).closest("button") || 
      (e.target as HTMLElement).closest("input") ||
      (e.target as HTMLElement).closest("select")
    ) {
      return;
    }
    setIsDragging(true);
    dragStart.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      setPosition({
        x: e.clientX - dragStart.current.x,
        y: e.clientY - dragStart.current.y,
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDragging]);

  // Focus input automatically when opened or resized
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, sizeMode]);

  // Keep expression ref up to date to avoid stale closures in keyboard handlers
  const expressionRef = useRef(expression);
  useEffect(() => {
    expressionRef.current = expression;
  }, [expression]);

  const safeEvaluate = (expr: string): string => {
    try {
      // Replace human multiplication (× or x or X) with '*' and division (÷) with '/'
      let cleaned = expr.replace(/[×xX]/g, "*").replace(/÷/g, "/").replace(/−/g, "-");
      // Prevent unauthorized characters, allow digits, standard mathematical operators, dots, parenthesies, and spaces
      cleaned = cleaned.replace(/[^0-9+\-*/().\s]/g, "");
      if (!cleaned.trim()) return "";
      
      // Perform safety evaluation
      const evalFn = new Function(`return ${cleaned}`);
      const val = evalFn();
      
      if (val === Infinity || val === -Infinity) return "Infinity";
      if (isNaN(val)) return "Error";
      
      // Convert float gracefully
      if (val % 1 !== 0) {
        return Number(val.toFixed(6)).toString();
      }
      return val.toString();
    } catch {
      return "Error";
    }
  };

  const handleCalculate = () => {
    const currentExpr = expressionRef.current;
    if (!currentExpr.trim()) return;
    const computed = safeEvaluate(currentExpr);
    setResult(computed);
    if (computed !== "Error") {
      setExpression(computed);
    }
  };

  const handleCharInput = (char: string) => {
    setExpression((prev) => prev + char);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleClear = () => {
    setExpression("");
    setResult("");
  };

  const handleBackspace = () => {
    setExpression((prev) => prev.slice(0, -1));
  };

  // Automatic global keypad handler when the popover is active
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      // Ignore keypad capturing if user is focused inside a different text/numeric input in the application
      if (
        document.activeElement &&
        document.activeElement !== inputRef.current &&
        (document.activeElement.tagName === "INPUT" ||
          document.activeElement.tagName === "TEXTAREA" ||
          (document.activeElement as HTMLElement).isContentEditable)
      ) {
        return;
      }

      const key = e.key;

      if (key === "Escape") {
        e.preventDefault();
        setIsOpen(false);
        return;
      }

      if (key === "Enter" || key === "=") {
        e.preventDefault();
        handleCalculate();
        return;
      }

      if (key === "Backspace") {
        if (document.activeElement !== inputRef.current) {
          e.preventDefault();
          handleBackspace();
        }
        return;
      }

      if (key.toLowerCase() === "c") {
        e.preventDefault();
        handleClear();
        return;
      }

      // Capture standard calculator keys and keypad mappings (including 'x' and 'X' for times)
      const validChars = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "+", "-", "*", "/", "(", ")", ".", "x", "X"];
      if (validChars.includes(key)) {
        if (document.activeElement !== inputRef.current) {
          e.preventDefault();
          let charToInput = key;
          if (key === "*" || key.toLowerCase() === "x") charToInput = "×";
          if (key === "/") charToInput = "÷";
          if (key === "-") charToInput = "−";
          handleCharInput(charToInput);
        }
      }
    };

    window.addEventListener("keydown", handleGlobalKeyDown);
    return () => {
      window.removeEventListener("keydown", handleGlobalKeyDown);
    };
  }, [isOpen]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleCalculate();
    } else if (e.key === "Escape") {
      setIsOpen(false);
    }
  };

  // Standard Mobile Calculator Layout (Regular)
  const regularLayout = [
    [
      { label: "C", value: "clear", style: "text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/20" },
      { label: "⌫", value: "backspace", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800" },
      { label: "÷", value: "÷", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" },
      { label: "×", value: "×", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" }
    ],
    [
      { label: "7", value: "7", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "8", value: "8", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "9", value: "9", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "−", value: "−", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" }
    ],
    [
      { label: "4", value: "4", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "5", value: "5", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "6", value: "6", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "+", value: "+", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" }
    ],
    [
      { label: "1", value: "1", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "2", value: "2", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "3", value: "3", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "=", value: "equal", style: "bg-gradient-to-tr from-indigo-500 to-indigo-600 text-white font-bold border-transparent shadow-md shadow-indigo-100 dark:shadow-none row-span-2 hover:from-indigo-600 hover:to-indigo-700 animate-pulse-slow" }
    ],
    [
      { label: "0", value: "0", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium col-span-2" },
      { label: ".", value: ".", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold" }
    ]
  ];

  // Professional Scientific/Numeric scale mode layout (Pro)
  const proLayout = [
    [
      { label: "C", value: "clear", style: "text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/40 hover:bg-rose-50 dark:hover:bg-rose-950/20 font-bold" },
      { label: "(", value: "(", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold" },
      { label: ")", value: ")", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold" },
      { label: "⌫", value: "backspace", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800" },
      { label: "÷", value: "÷", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" }
    ],
    [
      { label: "7", value: "7", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "8", value: "8", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "9", value: "9", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "%", value: "*0.01", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800" },
      { label: "×", value: "×", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" }
    ],
    [
      { label: "4", value: "4", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "5", value: "5", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "6", value: "6", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "1/x", value: "1/(", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs" },
      { label: "−", value: "−", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" }
    ],
    [
      { label: "1", value: "1", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "2", value: "2", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "3", value: "3", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium" },
      { label: "x²", value: "**2", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs" },
      { label: "+", value: "+", style: "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/20 font-bold" }
    ],
    [
      { label: "0", value: "0", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium col-span-2" },
      { label: ".", value: ".", style: "text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 font-bold" },
      { label: "√", value: "Math.sqrt(", style: "text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs" },
      { label: "=", value: "equal", style: "bg-gradient-to-tr from-indigo-500 to-indigo-600 text-white font-bold border-transparent shadow-md shadow-indigo-100 dark:shadow-none hover:from-indigo-600 hover:to-indigo-700 animate-pulse-slow" }
    ]
  ];

  const handleButtonClick = (btn: { label: string; value: string }) => {
    if (btn.value === "clear") {
      handleClear();
    } else if (btn.value === "backspace") {
      handleBackspace();
    } else if (btn.value === "equal") {
      handleCalculate();
    } else {
      handleCharInput(btn.value);
    }
  };

  const handleResetPosition = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <div className="relative shrink-0" ref={popoverRef}>
      {/* Dynamic Header Toggle Icon */}
      <button
        id="header-calculator-toggle"
        onClick={() => setIsOpen(!isOpen)}
        title="Quick Calculator Panel"
        className={`p-1.5 rounded-lg border transition-all shrink-0 flex items-center justify-center cursor-pointer ${
          isOpen
            ? "bg-indigo-50 dark:bg-indigo-950/40 border-indigo-400 text-indigo-600 dark:text-indigo-400 shadow-inner"
            : "border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 bg-white dark:bg-slate-800"
        }`}
      >
        <Calculator className="w-4 h-4 animate-pulse-slow" />
      </button>

      {/* Floating Independent Window using FIXED position to prevent being clipped by the header layout */}
      {isOpen && (
        <div 
          id="floating-calculator-window"
          className={`fixed bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.22)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.55)] z-55 overflow-hidden animate-fadeIn ${
            isDragging ? "" : "transition-all duration-300"
          } ${
            sizeMode === "pro" 
              ? "w-80" 
              : sizeMode === "regular" 
              ? "w-64" 
              : "w-56"
          }`}
          style={{
            top: "70px",
            right: "24px",
            transform: `translate(${position.x}px, ${position.y}px)`,
            cursor: isDragging ? "grabbing" : "default"
          }}
        >
          {/* Draggable Title Header Box */}
          <div 
            onMouseDown={handleMouseDown}
            title="Drag to reposition calculator"
            className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 px-3 py-2 bg-slate-100 dark:bg-slate-950/90 select-none cursor-grab active:cursor-grabbing"
          >
            <div className="flex items-center gap-1.5 shrink-0">
              <GripHorizontal className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <Calculator className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span className="font-sans font-bold text-slate-700 dark:text-slate-100 text-xs tracking-tight">
                Calculator
              </span>
            </div>
            
            {/* Quick Sizing Segmented Control Bars */}
            <div className="flex items-center gap-1.5">
              <div className="flex items-center gap-0.5 bg-slate-200/60 dark:bg-slate-900 p-0.5 rounded-md border border-slate-300/20 dark:border-slate-800">
                <button
                  onClick={() => setSizeMode("compact")}
                  title="Compact View (No Dial Pad)"
                  className={`text-[10px] px-1.5 py-0.5 rounded font-sans font-semibold transition-all cursor-pointer ${
                    sizeMode === "compact"
                      ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-200 shadow-xs"
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  }`}
                >
                  Sm
                </button>
                <button
                  onClick={() => setSizeMode("regular")}
                  title="Regular Mobile Calculator View"
                  className={`text-[10px] px-1.5 py-0.5 rounded font-sans font-semibold transition-all cursor-pointer ${
                    sizeMode === "regular"
                      ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-200 shadow-xs"
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  }`}
                >
                  Mid
                </button>
                <button
                  onClick={() => setSizeMode("pro")}
                  title="Professional Scientific Pad View"
                  className={`text-[10px] px-1.5 py-0.5 rounded font-sans font-semibold transition-all cursor-pointer ${
                    sizeMode === "pro"
                      ? "bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-200 shadow-xs"
                      : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  }`}
                >
                  Max
                </button>
              </div>

              {/* Close Button Button */}
              <button
                onClick={() => setIsOpen(false)}
                title="Close (Closes Popover)"
                className="p-1 rounded text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/20 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Calculator Output Displays (Beautiful mobile layout design screen display with high visibility) */}
          <div className="p-3 bg-slate-50 dark:bg-slate-950/40 border-b border-slate-100 dark:border-slate-800/60">
            {/* Small live sequence helper display */}
            <div className="text-right text-[11px] font-mono text-slate-400 dark:text-slate-500 tracking-wide min-h-[16px] mb-1 truncate">
              {result && result !== "Error" ? expression : ""}
            </div>

            <div className="relative">
              <input
                ref={inputRef}
                type="text"
                className="w-full text-right font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-black text-lg tracking-wide shadow-inner"
                placeholder="0"
                value={expression}
                onChange={(e) => {
                  // Standard dynamic visual replacement of native operators as typed
                  const val = e.target.value
                    .replace(/\*/g, "×")
                    .replace(/x/gi, "×")
                    .replace(/\//g, "÷")
                    .replace(/-/g, "−");
                  setExpression(val);
                }}
                onKeyDown={handleKeyDown}
              />
            </div>

            {/* Smart calculation details bar */}
            <div className="flex items-center justify-between mt-1 px-1">
              <div 
                onClick={handleResetPosition}
                className="text-[9px] text-slate-400 dark:text-slate-500 font-sans hover:text-indigo-500 cursor-pointer select-none"
                title="Reset overlay drag coordinates"
              >
                Reset Position
              </div>

              {result && (
                <div className={`font-mono font-black text-right text-emerald-600 dark:text-emerald-400 text-sm tracking-wide animate-fadeIn`}>
                  {result === "Error" ? "Invalid Expression" : `= ${result}`}
                </div>
              )}
            </div>
          </div>

          {/* DIALING SYSTEM KEYPAD - Conditional on sizes */}
          {sizeMode !== "compact" && (
            <div className="p-3 bg-white dark:bg-slate-900">
              <div className="space-y-1">
                {sizeMode === "pro" ? (
                  // Expanded scientific professional pad visual layout
                  proLayout.map((row, rIdx) => (
                    <div className="grid grid-cols-5 gap-1.5" key={rIdx}>
                      {row.map((btn, bIdx) => {
                        const isOperator = ["+", "−", "×", "÷"].includes(btn.label);
                        return (
                          <button
                            key={bIdx}
                            onClick={() => handleButtonClick(btn)}
                            className={`font-mono border flex items-center justify-center rounded-xl transition-all active:scale-95 duration-100 cursor-pointer shadow-sm ${
                              isOperator 
                                ? "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 bg-indigo-50/40 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 py-2.5 px-0.5 text-2xl font-black"
                                : btn.style
                            } ${
                              btn.value === "equal" 
                                ? "py-3 px-1.5 text-lg font-black shadow-md shadow-indigo-200 dark:shadow-none" 
                                : isOperator
                                ? "" // Already explicitly styled above
                                : ["1/x", "x²", "√"].includes(btn.label)
                                ? "py-2.5 px-0.5 text-xs font-semibold"
                                : "py-2.5 px-0.5 text-base font-bold"
                            } ${btn.label === "0" ? "col-span-2" : ""}`}
                          >
                            {btn.label}
                          </button>
                        );
                      })}
                    </div>
                  ))
                ) : (
                  // Classic elegant basic mobile view calculator layouts
                  regularLayout.map((row, rIdx) => (
                    <div className="grid grid-cols-4 gap-1.5" key={rIdx}>
                      {row.map((btn, bIdx) => {
                        const isOperator = ["+", "−", "×", "÷"].includes(btn.label);
                        return (
                          <button
                            key={bIdx}
                            onClick={() => handleButtonClick(btn)}
                            className={`font-mono border flex items-center justify-center rounded-xl transition-all active:scale-95 duration-100 cursor-pointer shadow-sm ${
                              isOperator
                                ? "text-indigo-600 dark:text-indigo-400 border-slate-200 dark:border-slate-800 bg-indigo-50/40 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 py-2.5 px-0.5 text-3xl font-black"
                                : btn.style
                            } ${
                              btn.value === "equal" 
                                ? "py-5 px-1 text-2xl font-black shadow-md shadow-indigo-200 dark:shadow-none h-full" 
                                : isOperator
                                ? "" // Already explicitly styled above
                                : "py-2.5 px-0.5 text-xl font-extrabold"
                            } ${btn.label === "0" ? "col-span-2" : ""}`}
                          >
                            {btn.label}
                          </button>
                        );
                      })}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Compact size display quick controls bar (rendered when sizeMode is 'compact') */}
          {sizeMode === "compact" && (
            <div className="p-2 px-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800/40 flex items-center justify-between gap-2.5">
              <button
                onClick={handleClear}
                className="px-3 py-1 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-450 text-[10px] font-bold rounded-lg border border-rose-200/50 dark:border-rose-900/10 cursor-pointer"
              >
                Clear
              </button>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleBackspace}
                  className="p-1 px-2 border border-slate-200 dark:border-slate-800 text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                  title="Backspace"
                >
                  <Delete className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleCalculate}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-lg shadow-sm cursor-pointer"
                >
                  =
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
