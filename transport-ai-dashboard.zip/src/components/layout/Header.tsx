import React, { useState, useEffect } from "react";
import { Truck, Cpu, Database, CheckCircle2, AlertTriangle, Moon, Sun, Menu } from "lucide-react";
import { useUiStore } from "../../store/uiStore";
import { CalculatorPopover } from "./CalculatorPopover";

interface HeaderProps {
  geminiConfigured: boolean;
  appUrl: string;
  userId?: string | null;
}

export function Header({ geminiConfigured, appUrl, userId }: HeaderProps) {
  const { isDarkMode, setIsDarkMode, isSidebarOpen, setIsSidebarOpen } = useUiStore();
  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);
  
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY && currentScrollY > 50) {
        setIsVisible(false);
      } else if (currentScrollY < lastScrollY) {
        setIsVisible(true);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  const handleLogout = async () => {
    try {
      const fb = await import("../../services/firebase");
      await fb.logout();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <header 
      className={`sticky top-0 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 z-40 shrink-0 shadow-sm transition-all duration-300 ease-in-out ${
        isVisible ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0 pointer-events-none"
      }`}
    >
      <div className="px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-4">
        {/* Brand Identity */}
        <div className="flex items-center gap-2 md:gap-3 shrink-0">
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="p-1.5 -ml-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Open Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="bg-gradient-to-tr from-indigo-500 to-indigo-600 p-2 rounded-lg text-white shadow-md shadow-indigo-100 dark:shadow-none">
            <Truck className="w-4 h-4 md:w-5 md:h-5" />
          </div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-850 dark:text-slate-100 tracking-tight font-sans">
              Transport AI
            </h1>
            <span className="hidden md:inline-block bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 text-[10px] font-semibold px-2 py-0.5 rounded-full tracking-wider uppercase">
              Enterprise
            </span>
          </div>
        </div>

        {/* Connection Status & Details Badges */}
        <div className="flex items-center justify-end gap-2 font-sans text-xs shrink-0 overflow-hidden">
          
          {/* Theme Toggle */}
          <button 
            onClick={toggleDarkMode}
            title="Toggle Theme"
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors bg-white dark:bg-slate-800 shrink-0"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-500" /> : <Moon className="w-4 h-4 text-indigo-500" />}
          </button>

          {/* Quick Access Calculator */}
          <CalculatorPopover />

          {/* User Status / Logout */}
          {userId && (
            <button 
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-xs font-semibold whitespace-nowrap"
            >
              Log out
            </button>
          )}

        </div>
      </div>
    </header>
  );
}
