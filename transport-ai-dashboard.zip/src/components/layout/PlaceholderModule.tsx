import React from 'react';
import { Settings2, HardHat } from 'lucide-react';

interface PlaceholderModuleProps {
  title: string;
  description: string;
}

export function PlaceholderModule({ title, description }: PlaceholderModuleProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-12 text-center bg-white dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/50 rounded-2xl animate-fadeIn">
      <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-6 shadow-inner">
        <HardHat className="w-8 h-8 text-indigo-500/80" />
      </div>
      <h2 className="text-2xl font-black text-slate-850 dark:text-slate-100 tracking-tight mb-2">
        {title} Runtime
      </h2>
      <p className="text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
        {description}
      </p>
      
      <div className="mt-8 flex gap-3">
        <div className="px-4 py-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-bold text-slate-500 uppercase tracking-widest border border-slate-200/50 dark:border-slate-700/50">
          Module Pending
        </div>
      </div>
    </div>
  );
}
