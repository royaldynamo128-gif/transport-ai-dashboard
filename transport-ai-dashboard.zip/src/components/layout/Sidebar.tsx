import React, { useEffect } from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  Users, 
  Truck, 
  CreditCard, 
  Receipt, 
  Send, 
  Map, 
  FileText, 
  MessageSquare, 
  Zap, 
  Settings,
  Building2,
  Wrench,
  Webhook,
  X
} from 'lucide-react';
import { useUiStore } from '../../store/uiStore';

export const MODULES = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
  { id: 'bookings', label: 'Bookings Database', icon: <BookOpen className="w-4 h-4" /> },
  { id: 'parties', label: 'Parties / Customers', icon: <Building2 className="w-4 h-4" /> },
  { id: 'drivers', label: 'Drivers', icon: <Users className="w-4 h-4" /> },
  { id: 'vehicles', label: 'Vehicles', icon: <Truck className="w-4 h-4" /> },
  { id: 'mechanics', label: 'Mechanics', icon: <Wrench className="w-4 h-4" /> },
  { id: 'payments', label: 'Payments', icon: <CreditCard className="w-4 h-4" /> },
  { id: 'expenses', label: 'Expenses', icon: <Receipt className="w-4 h-4" /> },
  { id: 'dispatch', label: 'Dispatch Center', icon: <Send className="w-4 h-4" /> },
  { id: 'tracking', label: 'Trip Tracking', icon: <Map className="w-4 h-4" /> },
  { id: 'ledger', label: 'Customer Ledger', icon: <FileText className="w-4 h-4" /> },
  { id: 'webhooks', label: 'Live API Webhooks', icon: <Webhook className="w-4 h-4" /> },
  { id: 'automations', label: 'Automations', icon: <Zap className="w-4 h-4" /> },
  { id: 'setup', label: 'System Settings', icon: <Settings className="w-4 h-4" /> },
];

export function Sidebar() {
  const { activeTab, setActiveTab, isSidebarOpen, setIsSidebarOpen } = useUiStore();

  // Close on Escape key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsSidebarOpen(false);
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [setIsSidebarOpen]);

  return (
    <>
      {/* Backdrop overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] transition-opacity duration-300" 
          onClick={() => setIsSidebarOpen(false)} 
        />
      )}

      {/* Drawer */}
      <div 
        className={`fixed top-0 left-0 h-full w-72 bg-slate-900 text-slate-300 flex flex-col shadow-2xl z-[110] transform transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 pt-6 pb-2 flex items-center justify-between">
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest pl-3">
            Modular ERP Core
          </div>
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <nav className="flex-1 px-3 space-y-1 mb-6 overflow-y-auto">
          {MODULES.map((mod) => (
            <button
              key={mod.id}
              onClick={() => {
                setActiveTab(mod.id as any);
                setIsSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === mod.id 
                  ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shadow-sm' 
                  : 'hover:bg-slate-800/50 hover:text-slate-100 border border-transparent'
              }`}
            >
              <div className={`${activeTab === mod.id ? 'text-indigo-400' : 'text-slate-500'}`}>
                {mod.icon}
              </div>
              {mod.label}
            </button>
          ))}
        </nav>
      </div>
    </>
  );
}
