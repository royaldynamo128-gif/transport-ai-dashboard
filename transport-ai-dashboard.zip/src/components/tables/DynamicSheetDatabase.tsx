import React, { useState, useCallback, useMemo, lazy, Suspense } from "react";
import { Search, Plus, Trash2, Edit, Save, X, Phone, MessageCircle, MoreVertical, Loader2, RefreshCw, Copy, MapPin, Share2, Map, Navigation, Zap, Tag, User, Calendar, IndianRupee, Blocks, Settings2, PlusCircle, XCircle, Edit2, LayoutGrid, Undo2, Redo2, CheckSquare, Square, Filter, ChevronDown, Download, Upload } from "lucide-react";
import * as XLSX from "xlsx";
import { motion } from "motion/react";
import { CustomTable, TableColumn, TableRow } from "../../types";
import { useTableStore } from "../../store/tableStore";
import { useUiStore } from "../../store/uiStore";
import { useExtensionStore } from "../../store/extensionStore";
import { useVirtualizer } from '@tanstack/react-virtual';

const ExtensionLibraryModal = lazy(() => import("../modals/ExtensionLibraryModal").then(m => ({ default: m.ExtensionLibraryModal })));

interface PhoneActionProps {
  phone: string;
  onClose: () => void;
}

function PhoneActionMenu({ phone, onClose }: PhoneActionProps) {
  const rawPhone = phone.replace(/\D/g, "");
  
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60" onClick={onClose} />
      <div className="relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl rounded-xl p-3 w-64 flex flex-col gap-2">
        <div className="pb-2 border-b border-slate-100 dark:border-slate-700 font-bold text-center text-slate-800 dark:text-slate-100 mb-1">
          {phone}
        </div>
        <a 
          href={`https://wa.me/${rawPhone}`} 
          target="_blank" 
          rel="noopener noreferrer"
          onClick={onClose}
          className="flex items-center justify-center gap-2 px-4 py-2 font-semibold bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-800/40 rounded-lg transition"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp Chat</span>
        </a>
        <div className="grid grid-cols-2 gap-2">
          <a 
            href={`tel:${rawPhone}`}
            onClick={onClose}
            className="flex items-center justify-center gap-2 px-3 py-2 font-semibold bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-800/40 rounded-lg transition"
          >
            <Phone className="w-4 h-4" />
            <span>Call</span>
          </a>
          <a 
            href={`sms:${rawPhone}`}
            onClick={onClose}
            className="flex items-center justify-center gap-2 px-3 py-2 font-semibold bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-800/40 rounded-lg transition"
          >
            <MessageCircle className="w-4 h-4" />
            <span>SMS</span>
          </a>
        </div>
        <button 
          onClick={() => {
            navigator.clipboard.writeText(phone);
            onClose();
          }}
          className="flex items-center justify-center gap-2 px-4 py-2 font-semibold bg-slate-50 dark:bg-slate-700/30 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition"
        >
          <Copy className="w-4 h-4" />
          <span>Copy Number</span>
        </button>
        <button onClick={onClose} className="mt-1 flex items-center justify-center gap-2 px-4 py-2 font-medium bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-lg transition">
          Cancel
        </button>
      </div>
    </div>
  );
}

interface LocationActionProps {
  location: string;
  onClose: () => void;
}

function LocationActionMenu({ location, onClose }: LocationActionProps) {
  const encLocation = encodeURIComponent(location);
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60" onClick={onClose} />
      <div className="relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl rounded-xl p-3 w-64 flex flex-col gap-2">
        <div className="pb-2 border-b border-slate-100 dark:border-slate-700 font-bold text-center text-slate-800 dark:text-slate-100 mb-1 truncate text-sm">
          {location}
        </div>
        <a 
          href={`https://www.google.com/maps/search/?api=1&query=${encLocation}`} 
          target="_blank" 
          rel="noopener noreferrer"
          onClick={onClose}
          className="flex items-center justify-center gap-2 px-4 py-2.5 font-semibold bg-rose-50 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-800/40 rounded-lg transition"
        >
          <Map className="w-4 h-4" />
          <span>Open Maps</span>
        </a>
        <div className="grid grid-cols-2 gap-2">
          <button 
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: 'Location', text: location, url: `https://www.google.com/maps/search/?api=1&query=${encLocation}` });
              }
              onClose();
            }}
            className="flex items-center justify-center gap-2 px-3 py-2 font-semibold bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-800/40 rounded-lg transition"
          >
            <Share2 className="w-4 h-4" />
            <span>Share</span>
          </button>
          <button 
            onClick={() => {
              navigator.clipboard.writeText(location);
              onClose();
            }}
            className="flex items-center justify-center gap-2 px-3 py-2 font-semibold bg-slate-50 dark:bg-slate-700/30 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 rounded-lg transition"
          >
            <Copy className="w-4 h-4" />
            <span>Copy</span>
          </button>
        </div>
        <button onClick={onClose} className="mt-1 flex items-center justify-center gap-2 px-4 py-2 font-medium bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-lg transition">
          Cancel
        </button>
      </div>
    </div>
  );
}

// Memoized Table Row for better rendering performance
const MemoizedTableRow = React.memo(({ 
  row, 
  activeTable, 
  editingRowId, 
  editRowForm, 
  setEditRowForm, 
  handleSaveRow, 
  setEditingRowId, 
  activePhoneMenu, 
  setActivePhoneMenu, 
  activeLocationMenu, 
  setActiveLocationMenu, 
  handleStartEditRow, 
  openAppModal, 
  handleDeleteAction,
  isNew,
  rowIndex,
  selectionBounds
}: any) => {
  const isEditing = editingRowId === row.id;

  return (
    <motion.tr 
      className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors"
      initial={isNew ? { opacity: 0, y: -10, backgroundColor: "rgba(99, 102, 241, 0.1)" } : { opacity: 1, y: 0, backgroundColor: "transparent" }}
      animate={{ opacity: 1, y: 0, backgroundColor: "transparent" }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      {isEditing ? (
        <>
          {/* Row handle / index column */}
          <td 
            data-r={rowIndex} 
            data-c={-1}
            className="p-3 w-10 text-center font-mono text-xs font-bold bg-slate-50 dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 text-slate-400 select-none cursor-row-resize"
          >
            {rowIndex + 1}
          </td>
          {activeTable.columns.map((col: any, colIndex: number) => (
            <td 
              key={col.id} 
              data-r={rowIndex} 
              data-c={colIndex} 
              className="p-3 border-b border-r border-slate-150/60 dark:border-slate-805/50 bg-indigo-50/15 dark:bg-indigo-950/15 relative after:absolute after:inset-0 after:border-2 after:border-indigo-500/85 dark:after:border-indigo-500/85 after:pointer-events-none transition-all duration-100 shadow-[inset_0_0_8px_rgba(99,102,241,0.12)]"
            >
              {col.type === 'status' ? (
                <select
                  value={editRowForm[col.id] !== undefined ? editRowForm[col.id] : (row[col.id] || "")}
                  onChange={e => setEditRowForm({...editRowForm, [col.id]: e.target.value})}
                  className="w-full bg-transparent border-0 border-transparent p-0 text-sm font-sans font-semibold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-0 cursor-pointer"
                >
                  <option value="">Select Status</option>
                  <option value="Pending">Pending</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Dispatched">Dispatched</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              ) : (
                <input 
                  type={col.type === 'date' ? 'date' : col.type === 'number' ? 'number' : 'text'}
                  autoComplete="off"
                  spellCheck={false}
                  value={editRowForm[col.id] !== undefined ? editRowForm[col.id] : (row[col.id] || "")}
                  onChange={e => setEditRowForm({...editRowForm, [col.id]: e.target.value})}
                  className="w-full bg-transparent border-0 border-transparent p-0 text-sm font-sans text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-0"
                />
              )}
            </td>
          ))}
          <td className="p-3 text-right flex gap-1 justify-end items-center border-b border-slate-150/60 dark:border-slate-805/50 bg-slate-50/10">
            <button onClick={handleSaveRow} className="text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 p-1.5 rounded" title="Save Row"><Save className="w-4 h-4" /></button>
            <button onClick={() => setEditingRowId(null)} className="text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-1.5 rounded" title="Cancel"><X className="w-4 h-4" /></button>
            <button 
              onClick={() => {
                openAppModal({
                  type: 'confirm',
                  title: 'Delete Row',
                  message: `Are you sure you want to delete this row? This action cannot be undone.`,
                  onConfirm: () => {
                    handleDeleteAction(row.id);
                    setEditingRowId(null);
                  }
                });
              }}
              className="text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 p-1.5 rounded"
              title="Delete Row"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </td>
        </>
      ) : (
        <>
          {/* Row handle / index column with dynamic selection styling */}
          <td 
            data-r={rowIndex} 
            data-c={-1}
            className={`p-3 text-center font-mono text-[11px] font-semibold select-none border-r border-b border-slate-205/60 dark:border-slate-800/85 bg-slate-50/50 dark:bg-slate-900/50 text-slate-400 dark:text-slate-500 cursor-row-resize transition-all ${
              (selectionBounds && rowIndex >= selectionBounds.minRow && rowIndex <= selectionBounds.maxRow && selectionBounds.minCol === 0 && selectionBounds.maxCol === activeTable.columns.length - 1)
                ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-400 font-extrabold border-r-2 border-r-indigo-500 shadow-[inset_-2px_0_0_0_rgba(99,102,241,1)]'
                : ''
            }`}
          >
            {rowIndex + 1}
          </td>
          {activeTable.columns.map((col: any, colIndex: number) => {
            const isSelectedCell = selectionBounds && 
              rowIndex >= selectionBounds.minRow && rowIndex <= selectionBounds.maxRow &&
              colIndex >= selectionBounds.minCol && colIndex <= selectionBounds.maxCol;
            return (
            <td 
              key={col.id} 
              data-r={rowIndex} 
              data-c={colIndex}
              onDoubleClick={() => handleStartEditRow(row)}
              onTouchStart={(e) => {
                const now = Date.now();
                const DOUBLE_TAP_DELAY = 300;
                const lastTap = (e.currentTarget as any).lastTap || 0;
                if (now - lastTap < DOUBLE_TAP_DELAY) {
                  handleStartEditRow(row);
                }
                (e.currentTarget as any).lastTap = now;
              }}
              className={`p-3 text-slate-700 dark:text-slate-300 border-b border-r border-slate-150/60 dark:border-slate-805/50 transition-all cursor-pointer hover:bg-slate-50/50 dark:hover:bg-slate-800/20 ${
                isSelectedCell 
                  ? 'bg-indigo-100/55 dark:bg-indigo-900/35 text-slate-900 dark:text-slate-100 relative after:absolute after:inset-0 after:border after:border-indigo-400 dark:after:border-indigo-500 after:pointer-events-none select-none' 
                  : ''
              }`}
              title="Double-click to edit"
            >
              {col.type === 'phone' && row[col.id] ? (
                <div className="relative inline-block">
                  <button 
                    onClick={() => setActivePhoneMenu({rowId: row.id, colId: col.id})}
                    className="text-blue-600 dark:text-blue-400 hover:underline hover:text-blue-800 cursor-pointer font-medium flex items-center gap-1"
                  >
                    {row[col.id]}
                  </button>
                  {activePhoneMenu?.rowId === row.id && activePhoneMenu?.colId === col.id && (
                    <PhoneActionMenu 
                      phone={row[col.id]} 
                      onClose={() => setActivePhoneMenu(null)} 
                    />
                  )}
                </div>
              ) : col.type === 'location' && row[col.id] ? (
                <div className="relative">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveLocationMenu({ rowId: row.id, colId: col.id });
                    }}
                    className="text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/40 px-1 py-0.5 rounded cursor-pointer font-medium flex items-center gap-1 transition"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span className="truncate max-w-[120px] inline-block">{row[col.id]}</span>
                  </button>
                  {activeLocationMenu?.rowId === row.id && activeLocationMenu?.colId === col.id && (
                    <LocationActionMenu 
                      location={row[col.id]} 
                      onClose={() => setActiveLocationMenu(null)} 
                    />
                  )}
                </div>
              ) : col.type === 'money' && row[col.id] ? (
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200 bg-emerald-50 dark:bg-emerald-900/20 px-1.5 py-0.5 rounded">
                  {Number(row[col.id]).toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })}
                </span>
              ) : col.type === 'driver' && row[col.id] ? (
                <span className="text-blue-700 dark:text-blue-400 font-medium hover:underline cursor-pointer flex items-center gap-1">
                  <span className="bg-blue-100 dark:bg-blue-900/40 w-5 h-5 rounded-full flex items-center justify-center text-[10px]">👨‍✈️</span>
                  {row[col.id]}
                </span>
              ) : col.type === 'status' ? (
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                  row[col.id] === 'Completed' || row[col.id] === 'Dispatched' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' :
                  row[col.id] === 'Pending' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400' :
                  row[col.id] === 'Cancelled' ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400' :
                  row[col.id] === 'In Progress' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' :
                  'bg-slate-100 dark:bg-slate-800'
                }`}>
                  {row[col.id]}
                </span>
              ) : col.type === 'tags' && row[col.id] ? (
                <div className="flex gap-1 flex-wrap">
                  {row[col.id].split(',').map((tag: string, i: number) => (
                    <span key={i} className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300 border border-purple-200 dark:border-purple-800/50">
                      {tag.trim()}
                    </span>
                  ))}
                </div>
              ) : (
                <span>{row[col.id]}</span>
              )}
            </td>
          )})}
          <td className="p-3 text-right border-b border-slate-150/60 dark:border-slate-805/50">
            <div className="flex gap-1 justify-end items-center">
              <button onClick={() => handleStartEditRow(row)} className="text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 p-1 rounded" title="Edit Row"><Edit className="w-4 h-4" /></button>
              <button 
                onClick={() => {
                  openAppModal({
                    type: 'confirm',
                    title: 'Delete Row',
                    message: `Are you sure you want to delete this row? This action cannot be undone.`,
                    onConfirm: () => {
                      handleDeleteAction(row.id);
                    }
                  });
                }}
                className="text-slate-400 hover:text-rose-500 dark:hover:text-rose-400 p-1 rounded"
                title="Delete Row"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </td>
        </>
      )}
    </motion.tr>
  );
}, (prevProps, nextProps) => {
  return prevProps.row === nextProps.row && 
    prevProps.activeTable === nextProps.activeTable && 
    prevProps.editingRowId === nextProps.editingRowId && 
    (prevProps.editingRowId !== prevProps.row.id && nextProps.editingRowId !== nextProps.row.id) &&
    prevProps.activePhoneMenu === nextProps.activePhoneMenu &&
    prevProps.activeLocationMenu === nextProps.activeLocationMenu &&
    prevProps.selectionBounds === nextProps.selectionBounds;
});

export function DynamicSheetDatabase() {
  const isIframe = typeof window !== 'undefined' && window.self !== window.top;
  const {
    customTables: tables,
    activeTableId,
    setActiveTableId: onSwitchTable,
    handleCreateTable: onCreateTable,
    handleRenameTable: onRenameTable,
    handleDuplicateTableSchema: onDuplicateTableSchema,
    handleUpdateColumns: onUpdateTableColumns,
    handleDeleteTableColumn: onDeleteTableColumn,
    handleAddRow: onAddRow,
    handleUpdateRow: onUpdateRow,
    handleDeleteRow: onDeleteRow,
    handleDeleteSelectedRows: onDeleteSelectedRows,
    handleDeleteSelectedColumns: onDeleteSelectedColumns,
    handleClearSelectedCells,
    handleImportData: onImportData,
    undo,
    redo,
    historyIndex,
    history,
    lastAction,
    clearLastAction
  } = useTableStore();
  const { setIsExtensionsModalOpen } = useExtensionStore();
  const activeTable = useMemo(() => tables.find(t => t.id === activeTableId) || tables[0], [tables, activeTableId]);
  const [editingColumnId, setEditingColumnId] = useState<string | null>(null);
  const [editingColName, setEditingColName] = useState("");
  const [editingRowId, setEditingRowId] = useState<string | null>(null);
  const [editRowForm, setEditRowForm] = useState<Record<string, any>>({});
  const [isAddingRow, setIsAddingRow] = useState(false);
  const [newRowForm, setNewRowForm] = useState<Record<string, any>>({});
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [tableSearch, setTableSearch] = useState("");
  const [globalSearchText, setGlobalSearchText] = useState("");
  const [showExportDropdown, setShowExportDropdown] = useState(false);
  const [showImportDropdown, setShowImportDropdown] = useState(false);
  const [showGoogleSheetModal, setShowGoogleSheetModal] = useState(false);
  const [googleSheetModalMode, setGoogleSheetModalMode] = useState<'import' | 'export'>('export');
  const [selectedFilterColumnId, setSelectedFilterColumnId] = useState("all");
  const [showFilterBar, setShowFilterBar] = useState(true);
  const [visibleCount, setVisibleCount] = useState(50);
  const [justAddedRowId, setJustAddedRowId] = useState<string | null>(null);
  const [selectionBounds, setSelectionBounds] = useState<{minRow: number, maxRow: number, minCol: number, maxCol: number} | null>(null);
  const [interactionMode, setInteractionMode] = useState<'select' | 'pan'>('pan');

  React.useEffect(() => {
    setInteractionMode('pan');
  }, [activeTableId]);

  const filteredRows = useMemo(() => {
    if (!activeTable || !activeTable.rows) return [];
    
    const searchVal = globalSearchText.toLowerCase().trim();
    if (!searchVal) return activeTable.rows;

    return activeTable.rows.filter(row => {
      if (!row) return false;
      
      if (selectedFilterColumnId === "all") {
        for (const col of activeTable.columns) {
          if (!col || !col.id) continue;
          const cellVal = String(row[col.id] || "").toLowerCase();
          if (cellVal.includes(searchVal)) {
            return true;
          }
        }
        return false;
      } else {
        if (!selectedFilterColumnId) return false;
        const cellVal = String(row[selectedFilterColumnId] || "").toLowerCase();
        return cellVal.includes(searchVal);
      }
    });
  }, [activeTable, globalSearchText, selectedFilterColumnId]);
  
  // Drag to scroll logic
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const isDragging = React.useRef(false);
  const hasDragged = React.useRef(false);
  const dragStart = React.useRef<{x: number, y: number, scrollLeft: number, scrollTop: number, r?: number, c?: number}>({ x: 0, y: 0, scrollLeft: 0, scrollTop: 0 });

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    // Don't intercept if clicking an interactive element
    const target = e.target as HTMLElement;
    if (target.closest('button, input, select, textarea, a')) {
      return; 
    }

    if (e.button === 1) e.preventDefault(); // Prevent middle-click auto-scroll
    
    isDragging.current = true;
    hasDragged.current = false;
    dragStart.current = {
      x: e.clientX,
      y: e.clientY,
      scrollLeft: scrollRef.current?.scrollLeft || 0,
      scrollTop: scrollRef.current?.scrollTop || 0
    };
    
    if (scrollRef.current) {
      scrollRef.current.setPointerCapture(e.pointerId);
      document.body.style.userSelect = 'none'; // Prevent text selection
      if (interactionMode === 'pan') {
        scrollRef.current.style.cursor = 'grabbing';
      }
    }

    if (interactionMode === 'pan') {
      return; // Skip selection logic on mouse down during panning
    }

    const td = (e.target as Element).closest('td, th');
    if (td) {
      const r = td.getAttribute('data-r');
      const c = td.getAttribute('data-c');
      if (r !== null && c !== null) {
        const rowIndex = parseInt(r, 10);
        const colIndex = parseInt(c, 10);
        dragStart.current = { ...dragStart.current, r: rowIndex, c: colIndex };
        
        if (colIndex === -1 && rowIndex === -1) {
          // Corner cell click selects the entire sheet!
          setSelectionBounds({
            minRow: 0,
            maxRow: filteredRows.length - 1,
            minCol: 0,
            maxCol: activeTable.columns.length - 1
          });
        } else if (colIndex === -1) {
          // Click down on row header selects entire row
          setSelectionBounds({
            minRow: rowIndex,
            maxRow: rowIndex,
            minCol: 0,
            maxCol: activeTable.columns.length - 1
          });
        } else if (rowIndex === -1) {
          // Click down on column header selects entire column
          setSelectionBounds({
            minRow: -1,
            maxRow: filteredRows.length - 1,
            minCol: colIndex,
            maxCol: colIndex
          });
        } else {
          setSelectionBounds({ minRow: rowIndex, maxRow: rowIndex, minCol: colIndex, maxCol: colIndex });
        }
      } else {
        setSelectionBounds(null);
      }
    } else {
      setSelectionBounds(null);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging.current || !scrollRef.current) return;
    
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
      hasDragged.current = true;
    }

    if (interactionMode === 'pan') {
      // Direct high-performance pan/scroll update
      scrollRef.current.scrollLeft = dragStart.current.scrollLeft - dx;
      scrollRef.current.scrollTop = dragStart.current.scrollTop - dy;
      return;
    }

    // Auto scroll if dragging near edges
    const edgeThreshold = 50;
    const rect = scrollRef.current.getBoundingClientRect();
    if (e.clientY < rect.top + edgeThreshold) scrollRef.current.scrollTop -= 10;
    if (e.clientY > rect.bottom - edgeThreshold) scrollRef.current.scrollTop += 10;
    if (e.clientX < rect.left + edgeThreshold) scrollRef.current.scrollLeft -= 10;
    if (e.clientX > rect.right - edgeThreshold) scrollRef.current.scrollLeft += 10;
    
    // Find element under pointer for touch/mouse drag
    const target = document.elementFromPoint(e.clientX, e.clientY);
    const td = target?.closest('td, th');
    if (td && dragStart.current.r !== undefined) {
      const r = td.getAttribute('data-r');
      const c = td.getAttribute('data-c');
      if (r !== null && c !== null) {
        let destR = parseInt(r, 10);
        let destC = parseInt(c, 10);
        const startR = dragStart.current.r as number;
        const startC = dragStart.current.c as number;
        
        if (startC === -1) {
          // Row selection drag: force selecting columns from 0 to last column
          setSelectionBounds({
            minRow: Math.min(startR, destR >= 0 ? destR : startR),
            maxRow: Math.max(startR, destR >= 0 ? destR : startR),
            minCol: 0,
            maxCol: activeTable.columns.length - 1
          });
        } else if (startR === -1) {
          // Column selection drag: force selecting rows from header -1 to bottom row
          setSelectionBounds({
            minRow: -1,
            maxRow: filteredRows.length - 1,
            minCol: Math.min(startC, destC >= 0 ? destC : startC),
            maxCol: Math.max(startC, destC >= 0 ? destC : startC)
          });
        } else {
          // Normal cell range drag-selection
          setSelectionBounds({
            minRow: Math.min(startR, destR >= 0 ? destR : startR),
            maxRow: Math.max(startR, destR >= 0 ? destR : startR),
            minCol: Math.min(startC, destC >= 0 ? destC : startC),
            maxCol: Math.max(startC, destC >= 0 ? destC : startC)
          });
        }
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isDragging.current) {
      isDragging.current = false;
      if (scrollRef.current) {
        scrollRef.current.releasePointerCapture(e.pointerId);
        document.body.style.userSelect = '';
        if (interactionMode === 'pan') {
          scrollRef.current.style.cursor = 'grab';
        }
      }

      // If user merely clicked without dragging, handle selection & double-click detection
      if (!hasDragged.current) {
        const target = document.elementFromPoint(e.clientX, e.clientY);
        const td = target?.closest('td, th');
        if (td) {
          const r = td.getAttribute('data-r');
          const c = td.getAttribute('data-c');
          if (r !== null && c !== null) {
            const rowIndex = parseInt(r, 10);
            const colIndex = parseInt(c, 10);

            // 1. Handle selection in pan-mode
            if (interactionMode === 'pan') {
              if (colIndex === -1) {
                setSelectionBounds({
                  minRow: rowIndex,
                  maxRow: rowIndex,
                  minCol: 0,
                  maxCol: activeTable.columns.length - 1
                });
              } else if (rowIndex === -1) {
                setSelectionBounds({
                  minRow: -1,
                  maxRow: filteredRows.length - 1,
                  minCol: colIndex,
                  maxCol: colIndex
                });
              } else {
                setSelectionBounds({
                  minRow: rowIndex,
                  maxRow: rowIndex,
                  minCol: colIndex,
                  maxCol: colIndex
                });
              }
            }

            // 2. Double-click/Double-tap detection to trigger inline editing on laptop or any pointer device
            if (rowIndex >= 0) {
              const row = filteredRows[rowIndex];
              if (row) {
                const now = Date.now();
                const lastPointerTap = (scrollRef.current as any)?.lastPointerTap || { time: 0, rowId: null };
                const DOUBLE_CLICK_DELAY = 300;
                if (now - lastPointerTap.time < DOUBLE_CLICK_DELAY && lastPointerTap.rowId === row.id) {
                  handleStartEditRow(row);
                  if (scrollRef.current) {
                    (scrollRef.current as any).lastPointerTap = { time: 0, rowId: null };
                  }
                } else {
                  if (scrollRef.current) {
                    (scrollRef.current as any).lastPointerTap = { time: now, rowId: row.id };
                  }
                }
              }
            }
          }
        }
      }

      setTimeout(() => {
        hasDragged.current = false;
      }, 50);
    }
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    if (hasDragged.current) {
      e.preventDefault();
    }
  };
  
  React.useEffect(() => {
    setVisibleCount(50);
  }, [activeTable.id]);
  
  // Google Sheets integration state
  const [needsAuth, setNeedsAuth] = useState(true);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [spreadsheetId, setSpreadsheetId] = useState("");
  const [isConnectingSheet, setIsConnectingSheet] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string>("");

  React.useEffect(() => {
    import("../../services/firebase").then(({ initAuth }) => {
      initAuth(
        (user, token) => {
          setNeedsAuth(false);
          setAccessToken(token);
        },
        () => {
          setNeedsAuth(true);
          setAccessToken(null);
        }
      );
    });
  }, []);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const { googleSignIn } = await import("../../services/firebase");
      const result = await googleSignIn();
      if (result) {
        setAccessToken(result.accessToken);
        setNeedsAuth(false);
      }
    } catch (err: any) {
      console.error("Login failed:", err);
      const isPopupError = err && (
        err.code === "auth/popup-closed-by-user" || 
        err.message?.includes("popup-closed-by-user") || 
        err.message?.includes("popup closed by user")
      );
      
      if (isIframe && isPopupError) {
        openAppModal({
          type: 'confirm',
          title: 'Google Sign-In Delayed',
          message: 'Because this application is running inside a secure code-editor preview iframe, Google Sign-In popups might be blocked or fail to communicate. To authorize, please click OK to open the app in a standalone browser tab and sign in successfully.',
          onConfirm: () => {
            window.open(window.location.href, '_blank');
          }
        });
      } else if (isPopupError) {
        openAppModal({
          type: 'confirm',
          title: 'Sign-In Popup Closed',
          message: 'The authorization popup window was closed before completing. If you had a popup blocker error or want to try again, click OK. You can also open the application in a new window.',
          onConfirm: () => {
            window.open(window.location.href, '_blank');
          }
        });
      } else {
        alert("Failed to sign in with Google: " + (err.message || err));
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSyncSheet = async () => {
    if (!spreadsheetId) {
      alert("Please enter a Spreadsheet ID or URL first.");
      return;
    }
    if (!accessToken) return;
    
    setIsConnectingSheet(true);
    setSyncStatus("Connecting...");
    try {
      const { fetchSpreadsheet, createSheetTab } = await import("../../services/sheets");
      
      let sheetId = spreadsheetId;
      if (sheetId.includes('/d/')) {
        sheetId = sheetId.split('/d/')[1].split('/')[0];
      }
      
      try {
        const data = await fetchSpreadsheet(sheetId, `${activeTable.name}!A:Z`, accessToken);
        if (data.values && data.values.length > 0) {
          setSyncStatus(`Successfully synced ${data.values.length - 1} rows!`);
          
          const headers: string[] = data.values[0] || [];
          const rows: any[][] = data.values.slice(1);
          
          const newCols: TableColumn[] = headers.map((h, i) => ({
            id: `col_sync_${i}`,
            name: h || `Column ${i+1}`,
            type: "text"
          }));
          
          const newRows: TableRow[] = rows.map((rowArr, i) => {
            const rowObj: Record<string, any> = { id: `R_${Date.now()}_${i}` };
            newCols.forEach((col, j) => {
              rowObj[col.id] = rowArr[j] || "";
            });
            return rowObj as TableRow;
          });

          if (onImportData) {
            onImportData(activeTable.id, newCols, newRows);
          }
        } else {
          setSyncStatus("Sheet connected but looks empty. Please ensure data is correctly tabulated.");
        }
      } catch (innerError: any) {
        if (innerError.message && innerError.message.includes("Unable to parse range")) {
          setSyncStatus(`Tab "${activeTable.name}" not found. Creating it now...`);
          try {
            const headers = activeTable.columns.map(c => c.name);
            await createSheetTab(sheetId, activeTable.name, headers, accessToken);
            setSyncStatus(`Successfully created tab "${activeTable.name}" in your Google Sheet! Try syncing again.`);
          } catch (createErr: any) {
            setSyncStatus("Error creating tab: " + createErr.message);
          }
        } else {
          throw innerError;
        }
      }
    } catch (e: any) {
      console.error("Sync error:", e);
      setSyncStatus("Error: " + e.message);
    } finally {
      setIsConnectingSheet(false);
    }
  };

  const handleExportToExcel = () => {
    try {
      if (!activeTable || !activeTable.rows || activeTable.rows.length === 0) {
        alert("There is no data to export.");
        return;
      }
      const dataToExport = activeTable.rows.map((row) => {
        const formattedRow: Record<string, any> = {};
        activeTable.columns.forEach((col) => {
          formattedRow[col.name] = row[col.id] || "";
        });
        return formattedRow;
      });

      const worksheet = XLSX.utils.json_to_sheet(dataToExport);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, activeTable.name.substring(0, 31));
      XLSX.writeFile(workbook, `${activeTable.name.replace(/[^a-zA-Z0-9]/g, "_")}.xlsx`);
      setSyncStatus(`Excel file "${activeTable.name}.xlsx" downloaded!`);
    } catch (err: any) {
      console.error(err);
      alert("Failed to export to Excel: " + err.message);
    }
  };

  const handleExportToGoogleSheet = async (createNew: boolean) => {
    if (!accessToken) {
      alert("Please sign in with Google first.");
      return;
    }
    setIsConnectingSheet(true);
    setSyncStatus("Exporting to Google Sheets...");
    try {
      const { createSpreadsheet, updateSpreadsheetValues } = await import("../../services/sheets");
      
      let targetSpreadsheetId = spreadsheetId;
      if (createNew) {
        const response = await createSpreadsheet(`Export: ${activeTable.name}`, accessToken);
        targetSpreadsheetId = response.spreadsheetId;
        setSpreadsheetId(targetSpreadsheetId);
      } else {
        if (!targetSpreadsheetId) {
          alert("Please enter a Spreadsheet ID or URL first, or select 'Create New Google Sheet'.");
          setIsConnectingSheet(false);
          setSyncStatus("");
          return;
        }
        if (targetSpreadsheetId.includes('/d/')) {
          targetSpreadsheetId = targetSpreadsheetId.split('/d/')[1].split('/')[0];
        }
      }

      // Format data: headers as index 0, then a grid of rows
      const headers = activeTable.columns.map(col => col.name);
      const rowsData = activeTable.rows.map(row => 
        activeTable.columns.map(col => row[col.id] || "")
      );

      const values = [headers, ...rowsData];
      const range = `${activeTable.name.substring(0, 31)}!A1`;
      
      await updateSpreadsheetValues(targetSpreadsheetId, range, values, accessToken);
      
      setSyncStatus(`Successfully exported ${activeTable.rows.length} rows to Google Sheet!`);
      
      openAppModal({
        type: 'confirm',
        title: 'Google Sheet Exported',
        message: `Your table has been exported successfully. Click OK to open your Google Sheet.`,
        onConfirm: () => {
          window.open(`https://docs.google.com/spreadsheets/d/${targetSpreadsheetId}`, '_blank');
        }
      });
    } catch (err: any) {
      console.error(err);
      setSyncStatus("Export failed: " + err.message);
      alert("Export failed: " + err.message);
    } finally {
      setIsConnectingSheet(false);
    }
  };

  const handleImportFromExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData: any[] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (jsonData.length === 0) {
          alert("The Excel file is empty.");
          return;
        }

        const headers = jsonData[0] as string[];
        const rowsData = jsonData.slice(1) as any[][];

        const newCols: TableColumn[] = headers.map((h, i) => ({
          id: `col_xls_${Date.now()}_${i}`,
          name: h || `Column ${i+1}`,
          type: "text"
        }));

        const newRows: TableRow[] = rowsData.map((rowArr, i) => {
          const rowObj: Record<string, any> = { id: `R_xls_${Date.now()}_${i}` };
          newCols.forEach((col, j) => {
            rowObj[col.id] = rowArr[j] !== undefined && rowArr[j] !== null ? String(rowArr[j]) : "";
          });
          return rowObj as TableRow;
        });

        openAppModal({
          type: 'confirm',
          title: 'Confirm Excel Import',
          message: `This will REPLACE all current columns and rows of "${activeTable.name}" with the ${newRows.length} rows from your Excel file. Do you want to proceed?`,
          onConfirm: async () => {
            if (onImportData) {
              await onImportData(activeTable.id, newCols, newRows);
              setSyncStatus(`Successfully imported ${newRows.length} rows from Excel!`);
            }
          }
        });

      } catch (err: any) {
        console.error(err);
        alert("Failed to parse Excel: " + err.message);
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = "";
  };

  const { appModalConfig, openAppModal, closeAppModal } = useUiStore();

  const [activePhoneMenu, setActivePhoneMenu] = useState<{rowId: string, colId: string} | null>(null);
  const [activeLocationMenu, setActiveLocationMenu] = useState<{rowId: string, colId: string} | null>(null);

  const handleStartEditCol = (col: TableColumn) => {
    setEditingColumnId(col.id);
    setEditingColName(col.name);
  };
  
  const handleSaveCol = () => {
    if (!editingColumnId || !editingColName.trim()) return;
    const newCols = activeTable.columns.map(c => 
      c.id === editingColumnId ? { ...c, name: editingColName } : c
    );
    onUpdateTableColumns(activeTable.id, newCols);
    setEditingColumnId(null);
  };

  const handleDeleteCol = () => {
    if (!editingColumnId) return;
    openAppModal({
      type: 'confirm',
      title: 'Delete Column',
      message: 'Do you really want to delete this table, this column? Do you really want to delete this column for safety purposes?',
      onConfirm: () => {
        onDeleteTableColumn(activeTable.id, editingColumnId);
        setEditingColumnId(null);
      }
    });
  };

  const handleStartEditRow = useCallback((row: TableRow) => {
    setEditingRowId(row.id);
    setEditRowForm({ ...row });
  }, []);

  const handleSaveRow = useCallback(() => {
    if (editingRowId) {
      onUpdateRow(activeTable.id, editingRowId, editRowForm);
      setEditingRowId(null);
    }
  }, [editingRowId, editRowForm, onUpdateRow, activeTable.id]);
  
  const handleDeleteAction = useCallback((id: string) => {
    onDeleteRow(activeTable.id, id);
  }, [onDeleteRow, activeTable.id]);
  
  const handleAddNewRow = async () => {
    const newId = `R_${Date.now()}`;
    const rowData = { ...newRowForm, id: newId };
    onAddRow(activeTable.id, rowData);
    setIsAddingRow(false);
    setNewRowForm({});
    setJustAddedRowId(newId);
    setTimeout(() => setJustAddedRowId(null), 2000);
    
    // Optionally push to Google Sheets
    if (spreadsheetId && accessToken) {
      try {
        const { appendToSpreadsheet } = await import("../../services/sheets");
        let sheetId = spreadsheetId;
        if (sheetId.includes('/d/')) {
          sheetId = sheetId.split('/d/')[1].split('/')[0];
        }
        
        // Prepare array of values ordered by columns
        const values = activeTable.columns.map(col => rowData[col.id] || "");
        
        await appendToSpreadsheet(sheetId, `${activeTable.name}!A:Z`, [values], accessToken);
        setSyncStatus("Row added and synced to Google Sheets.");
      } catch (e: any) {
        console.error("Error pushing to sheet:", e);
        setSyncStatus("Added locally, but failed to sync to sheet.");
      }
    }
  };

  const handleDeleteSelection = React.useCallback(async () => {
    if (!selectionBounds) return;
    const { minRow, maxRow, minCol, maxCol } = selectionBounds;

    const isHeaderIncluded = minRow === -1;
    const allRowsSelected = maxRow >= filteredRows.length - 1 && (minRow <= 0);
    const allColsSelected = minCol === 0 && maxCol === activeTable.columns.length - 1;

    if (isHeaderIncluded && allRowsSelected) {
      // complete column removed permanently
      const colIds = [];
      for (let c = minCol; c <= maxCol; c++) {
        colIds.push(activeTable.columns[c].id);
      }
      onDeleteSelectedColumns(activeTable.id, colIds);
    } else if (!isHeaderIncluded && allRowsSelected && !allColsSelected) {
      // selects an entire column without including the column header -> only data deleted
      const colIds = [];
      for (let c = minCol; c <= maxCol; c++) {
        colIds.push(activeTable.columns[c].id);
      }
      const rowIds = filteredRows.map(r => r.id);
      handleClearSelectedCells(activeTable.id, rowIds, colIds);
    } else if (!isHeaderIncluded && allColsSelected) {
      // selects an entire row -> full row deleted
      const rowIds = [];
      for (let r = minRow; r <= maxRow; r++) {
         if (filteredRows[r]) rowIds.push(filteredRows[r].id);
      }
      await onDeleteSelectedRows(activeTable.id, rowIds);
    } else {
      // selects only some cells inside the table, or partial rows and partial columns -> only selected cell data deleted
      const colIds = [];
      for (let c = minCol; c <= maxCol; c++) {
        colIds.push(activeTable.columns[c].id);
      }
      const rowIds = [];
      const startR = Math.max(0, minRow);
      for (let r = startR; r <= maxRow; r++) {
         if (filteredRows[r]) rowIds.push(filteredRows[r].id);
      }
      handleClearSelectedCells(activeTable.id, rowIds, colIds);
    }
    setSelectionBounds(null);
  }, [selectionBounds, filteredRows, activeTable, onDeleteSelectedColumns, handleClearSelectedCells, onDeleteSelectedRows]);

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput = target instanceof HTMLInputElement || 
                      target instanceof HTMLTextAreaElement || 
                      target instanceof HTMLSelectElement ||
                      target.isContentEditable;
      
      if (e.key === 'Escape') {
        setIsAddingRow(false);
        setEditingRowId(null);
        setEditingColumnId(null);
        setIsMenuOpen(false);
        setActivePhoneMenu(null);
        setActiveLocationMenu(null);
        if (isInput) target.blur();
      }
      
      if (e.key === 'n' && !isInput && !(e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setIsAddingRow(true);
      }
      
      if ((e.key === 'Backspace' || e.key === 'Delete') && !isInput && selectionBounds) {
         e.preventDefault();
         handleDeleteSelection();
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        if (!isInput) {
          e.preventDefault();
          if (e.shiftKey) {
            redo();
          } else {
            undo();
          }
        }
      }
      
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'y') {
         if (!isInput) {
            e.preventDefault();
            redo();
         }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectionBounds, handleDeleteSelection, undo, redo]);

  React.useEffect(() => {
    if (lastAction) {
      const timer = setTimeout(() => {
        clearLastAction();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [lastAction, clearLastAction]);

  const getScrollElement = useCallback(() => scrollRef.current, []);
  const estimateSize = useCallback(() => 48, []);

  const rowVirtualizer = useVirtualizer({
    count: filteredRows.length,
    getScrollElement,
    estimateSize,
    overscan: 20,
  });

  return (
    <div className="flex flex-col gap-4 font-sans h-full">
      {/* Main Table Interface */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm relative flex flex-col">
        <div className="p-4 rounded-t-2xl border-b border-slate-200 dark:border-slate-800 flex flex-wrap justify-between items-center gap-4 bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3 relative group flex-wrap">
            <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100">{activeTable.name}</h3>
            
            <div className="opacity-0 group-hover:opacity-100 flex items-center transition-opacity gap-1">
              {onRenameTable && (
                <button
                  onClick={() => {
                    openAppModal({
                      type: 'prompt',
                      title: 'Rename Table',
                      message: 'Enter new name for this table:',
                      onConfirm: (newName) => {
                        if (newName && newName.trim()) {
                          onRenameTable(activeTable.id, newName.trim());
                        }
                      }
                    });
                  }}
                  className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 bg-slate-100 dark:bg-slate-800 rounded-md transition"
                  title="Rename Table"
                >
                  <Edit className="w-3.5 h-3.5" />
                </button>
              )}
              {onDuplicateTableSchema && (
                <button
                  onClick={() => {
                    openAppModal({
                      type: 'prompt',
                      title: 'Duplicate Schema',
                      message: 'Enter name for the copied table:',
                      onConfirm: (newName) => {
                        if (newName && newName.trim()) {
                          onDuplicateTableSchema(activeTable.id, newName.trim());
                        }
                      }
                    });
                  }}
                  className="p-1.5 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 bg-slate-100 dark:bg-slate-800 rounded-md transition"
                  title="Copy Table Schema"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Interaction mode toggles (Select vs Pan/Scroll) */}
            <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-700 pl-3 bg-slate-100/50 dark:bg-slate-800/40 p-0.5 rounded-lg">
              <button
                onClick={() => setInteractionMode('select')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition duration-150 text-xs font-semibold ${
                  interactionMode === 'select'
                    ? 'bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 shadow-sm border border-slate-200/80 dark:border-slate-600'
                    : 'text-slate-500 hover:text-slate-750 dark:hover:text-slate-200'
                }`}
                title="Cell Selection Mode (drag to select cells/rows)"
              >
                <span>🖱️</span>
                <span className="hidden sm:inline">Selection Mode</span>
              </button>
              <button
                onClick={() => setInteractionMode('pan')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition duration-150 text-xs font-semibold ${
                  interactionMode === 'pan'
                    ? 'bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 shadow-sm border border-slate-200/80 dark:border-slate-600'
                    : 'text-slate-500 hover:text-slate-755 dark:hover:text-slate-200'
                }`}
                title="Pan/Scroll Mode (drag to scroll/swipe table dynamically)"
              >
                <span>✋</span>
                <span className="hidden sm:inline">Swipe/Pan Mode</span>
              </button>
            </div>

            {/* Undo/Redo Controls */}
            <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-700 pl-3">
              <button
                onClick={undo}
                disabled={historyIndex === 0}
                className="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent rounded transition-colors"
                title="Undo"
              >
                <Undo2 className="w-4 h-4" />
              </button>
              <button
                onClick={redo}
                disabled={historyIndex >= history.length - 1}
                className="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-transparent rounded transition-colors"
                title="Redo"
              >
                <Redo2 className="w-4 h-4" />
              </button>
            </div>
            
            <div className="border-l border-slate-200 dark:border-slate-700 pl-3 flex items-center gap-2">
              {selectionBounds && (
                <button
                  onClick={handleDeleteSelection}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-900/30 dark:hover:bg-rose-900/50 dark:text-rose-400 text-sm font-medium rounded-lg flex items-center gap-1.5 transition-colors shadow-sm border border-rose-200 dark:border-rose-800/80"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Selected</span>
                </button>
              )}
            </div>

            {/* Three-dot menu for all tables */}
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="p-1.5 rounded-md hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 transition-colors ml-2"
              title="View All Tables"
            >
              <MoreVertical className="w-5 h-5" />
            </button>

            {isMenuOpen && (
              <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-slate-900/60" onClick={() => setIsMenuOpen(false)} />
                <div className="relative w-full max-w-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl rounded-2xl overflow-hidden flex flex-col animate-fadeIn">
                  <div className="p-4 border-b border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between">
                    <h3 className="font-bold text-slate-800 dark:text-slate-100">All Tables</h3>
                    <button onClick={() => setIsMenuOpen(false)} className="text-slate-400 hover:text-red-500 transition-colors"><X className="w-5 h-5"/></button>
                  </div>
                  <div className="p-3 border-b border-slate-100 dark:border-slate-700">
                    <div className="relative">
                      <Search className="w-5 h-5 absolute left-3 top-2.5 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="Search tables..." 
                        autoComplete="off"
                        spellCheck={false}
                        value={tableSearch}
                        onChange={e => setTableSearch(e.target.value)}
                        className="w-full pl-10 pr-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all text-slate-800 dark:text-slate-100"
                      />
                    </div>
                  </div>
                  <div className="max-h-[60vh] overflow-y-auto p-2 flex flex-col gap-1">
                    {tables.filter(t => t.name.toLowerCase().includes(tableSearch.toLowerCase())).map(table => (
                      <button
                        key={table.id}
                        onClick={() => {
                          onSwitchTable(table.id);
                          setIsMenuOpen(false);
                        }}
                        className={`text-left px-4 py-3 text-sm rounded-xl transition-all ${
                          activeTableId === table.id 
                          ? "bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 font-bold shadow-sm" 
                          : "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60"
                        }`}
                      >
                        {table.name} 
                        {activeTableId === table.id && <span className="float-right bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-400 text-[10px] uppercase font-bold px-2 py-0.5 rounded">Active</span>}
                      </button>
                    ))}
                    {tables.filter(t => t.name.toLowerCase().includes(tableSearch.toLowerCase())).length === 0 && (
                      <div className="text-center py-8 text-sm text-slate-500">No tables found matched your search.</div>
                    )}
                  </div>
                  <div className="p-3 border-t border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
                    <button 
                      onClick={() => {
                        setIsMenuOpen(false);
                        openAppModal({
                          type: 'prompt',
                          title: 'Create New Table',
                          message: 'Enter new table name:',
                          onConfirm: (name) => {
                            if (name && name.trim()) {
                              onCreateTable(name.trim());
                            }
                          }
                        });
                      }}
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-bold bg-white dark:bg-slate-800 border-2 border-indigo-100 dark:border-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl hover:bg-indigo-50 dark:hover:bg-indigo-900/30 hover:border-indigo-200 transition-all shadow-sm"
                    >
                      <Plus className="w-5 h-5" /> Create New Table
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 relative shrink-0">
            <button 
              onClick={() => {
                const newCols = [...activeTable.columns, { id: `col_${Date.now()}`, name: "New Column", type: "text" as const }];
                onUpdateTableColumns(activeTable.id, newCols);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-200/80 hover:bg-slate-300 dark:bg-slate-800 hover:dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition shrink-0 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Add Column</span>
              <span className="sm:hidden">Col</span>
            </button>
            
            <button
               onClick={() => setIsExtensionsModalOpen(true)}
               className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 text-xs font-bold rounded-lg transition shrink-0 whitespace-nowrap shadow-[0_0_15px_rgba(99,102,241,0.15)] glow-indigo"
            >
               <Zap className="w-3.5 h-3.5 text-indigo-500 fill-indigo-500/20" />
               <span className="hidden sm:inline">Extensions</span>
               <span className="sm:hidden">Ext</span>
            </button>

            <button 
              onClick={() => setIsAddingRow(!isAddingRow)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg transition shrink-0 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              {isAddingRow ? "Cancel" : <span className="hidden sm:inline">Add Row</span>}
              {!isAddingRow && <span className="sm:hidden">Row</span>}
            </button>

            <button
               onClick={() => setShowFilterBar(!showFilterBar)}
               className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition shrink-0 whitespace-nowrap border ${
                 showFilterBar 
                   ? "bg-indigo-550/10 border-indigo-500/20 text-indigo-600 dark:text-indigo-400" 
                   : "bg-slate-200/80 hover:bg-slate-300 dark:bg-slate-800 hover:dark:bg-slate-700 text-slate-700 dark:text-slate-300 border-transparent"
               }`}
               title="Toggle Search Filter Bar"
            >
               <Filter className="w-3.5 h-3.5" />
               <span>Filter</span>
            </button>

            {/* Import Button with Dropdown */}
            <div className="relative">
              <button 
                onClick={() => {
                  setShowImportDropdown(!showImportDropdown);
                  setShowExportDropdown(false);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition shrink-0 whitespace-nowrap border ${
                  showImportDropdown
                    ? "bg-indigo-500/10 border-indigo-500/20 text-indigo-600 dark:text-indigo-400 font-bold" 
                    : "bg-slate-200/80 hover:bg-slate-300 dark:bg-slate-800 hover:dark:bg-slate-700 text-slate-700 dark:text-slate-300 border-transparent"
                }`}
                title="Import Excel or Google Sheet"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Import</span>
                <ChevronDown className="w-3 h-3 opacity-60 ml-px" />
              </button>

              {showImportDropdown && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowImportDropdown(false)} />
                  <div className="absolute right-0 mt-1.5 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-xl z-50 overflow-hidden py-1 animate-fadeIn">
                    <button
                      onClick={async () => {
                        setShowImportDropdown(false);
                        setGoogleSheetModalMode('import');
                        setShowGoogleSheetModal(true);
                      }}
                      className="w-full text-left px-3 py-2.5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 transition"
                    >
                      <svg viewBox="0 0 24 24" className="w-4 h-4 text-emerald-600">
                        <path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2Z"/>
                      </svg>
                      Import in Google Sheet
                    </button>

                    <label className="w-full text-left px-3 py-2.5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 cursor-pointer transition">
                      <svg viewBox="0 0 24 24" className="w-4 h-4 text-indigo-600">
                        <path fill="currentColor" d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
                      </svg>
                      <span>Import from Excel</span>
                      <input 
                        type="file" 
                        accept=".xlsx, .xls" 
                        onChange={(e) => {
                          setShowImportDropdown(false);
                          handleImportFromExcel(e);
                        }} 
                        className="hidden" 
                      />
                    </label>
                  </div>
                </>
              )}
            </div>

            {/* Export Button with Dropdown */}
            <div className="relative">
              <button 
                onClick={() => {
                  setShowExportDropdown(!showExportDropdown);
                  setShowImportDropdown(false);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition shrink-0 whitespace-nowrap border ${
                  showExportDropdown
                    ? "bg-indigo-500/10 border-indigo-500/20 text-indigo-600 dark:text-indigo-400 font-bold" 
                    : "bg-slate-200/80 hover:bg-slate-300 dark:bg-slate-800 hover:dark:bg-slate-700 text-slate-700 dark:text-slate-300 border-transparent"
                }`}
                title="Export Excel or Google Sheet"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export</span>
                <ChevronDown className="w-3 h-3 opacity-60 ml-px" />
              </button>

              {showExportDropdown && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowExportDropdown(false)} />
                  <div className="absolute right-0 mt-1.5 w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-xl z-50 overflow-hidden py-1 animate-fadeIn">
                    <button
                      onClick={async () => {
                        setShowExportDropdown(false);
                        setGoogleSheetModalMode('export');
                        setShowGoogleSheetModal(true);
                      }}
                      className="w-full text-left px-3 py-2.5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 transition"
                    >
                      <svg viewBox="0 0 24 24" className="w-4 h-4 text-emerald-600">
                        <path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2Z"/>
                      </svg>
                      Export to Google Sheet
                    </button>

                    <button
                      onClick={() => {
                        setShowExportDropdown(false);
                        handleExportToExcel();
                      }}
                      className="w-full text-left px-3 py-2.5 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 transition"
                    >
                      <svg viewBox="0 0 24 24" className="w-4 h-4 text-indigo-600">
                        <path fill="currentColor" d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
                      </svg>
                      Export to Excel
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Dynamic Foldable Filter Bar */}
        {showFilterBar && (
          <div className="w-full bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800 px-4 py-2.5 flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 select-none">
              <Filter className="w-3.5 h-3.5 text-indigo-500" />
              <span>Search Database:</span>
            </div>
            
            <div className="relative flex items-center max-w-md w-full">
              <input 
                type="text"
                autoComplete="off"
                spellCheck={false}
                value={globalSearchText}
                onChange={(e) => setGlobalSearchText(e.target.value)}
                placeholder="Search values..."
                className="w-full pl-8 pr-32 py-1.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400"
              />
              <div className="absolute left-2.5 text-slate-400 pointer-events-none">
                <Search className="w-3.5 h-3.5" />
              </div>
              
              <div className="absolute right-1 top-0.5 bottom-0.5 flex items-center pr-1 border-l border-slate-200 dark:border-slate-800 pl-2">
                <select
                  value={selectedFilterColumnId}
                  onChange={(e) => setSelectedFilterColumnId(e.target.value)}
                  className="appearance-none bg-transparent hover:bg-slate-100 dark:hover:bg-slate-900 text-[10px] sm:text-xs font-bold text-slate-600 dark:text-slate-350 select-none cursor-pointer pr-5 pl-1.5 py-0.5 focus:outline-none text-right font-sans"
                >
                  <option value="all">All Columns</option>
                  {activeTable.columns.map(col => (
                    <option key={col.id} value={col.id} className="text-slate-800 dark:text-slate-200">{col.name}</option>
                  ))}
                </select>
                <div className="pointer-events-none absolute right-2 text-slate-400">
                  <ChevronDown className="w-2.5 h-2.5" />
                </div>
              </div>
            </div>

            {globalSearchText && (
              <button 
                onClick={() => setGlobalSearchText("")}
                className="text-[10px] font-bold text-indigo-600 hover:text-indigo-500 bg-indigo-500/10 hover:bg-indigo-500/20 px-2.5 py-1 rounded-md transition duration-150"
              >
                Clear
              </button>
            )}
          </div>
        )}

        <div 
          ref={scrollRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onContextMenu={handleContextMenu}
          onClickCapture={(e) => {
            if (hasDragged.current) {
              e.stopPropagation();
              e.preventDefault();
            }
          }}
          className={`overflow-auto max-h-[75vh] pb-32 min-h-[400px] rounded-b-2xl select-none ${
            interactionMode === 'pan' ? 'cursor-grab' : 'cursor-cell'
          }`}
          style={{ touchAction: 'pan-x pan-y' }}
        >
          <table className="w-full text-left text-sm whitespace-nowrap border-separate border-spacing-0">
            <thead className="sticky top-0 z-10 bg-slate-50 dark:bg-slate-900 shadow-sm">
              <tr>
                <th 
                  data-r={-1} 
                  data-c={-1}
                  className="p-3 w-10 text-center font-mono text-[10px] font-bold text-slate-400 dark:text-slate-500 bg-slate-100/90 dark:bg-slate-900/90 border-b border-r border-slate-200 dark:border-slate-800 select-none cursor-crosshair"
                >
                  #
                </th>
                {activeTable.columns.map((col, colIndex) => {
                  const isBeingEdited = editingColumnId === col.id;
                  return (
                    <th 
                      key={col.id} 
                      data-r={-1} 
                      data-c={colIndex} 
                      onDoubleClick={() => handleStartEditCol(col)}
                      className={`p-3 font-semibold text-slate-600 dark:text-slate-300 text-xs uppercase tracking-wider relative group select-none cursor-pointer transition-all ${
                        isBeingEdited 
                          ? 'bg-indigo-50/40 dark:bg-indigo-950/40 after:absolute after:inset-0 after:border-2 after:border-indigo-500 dark:after:border-indigo-500 after:pointer-events-none' 
                          : ''
                      } ${
                        (selectionBounds && selectionBounds.minRow === -1 && colIndex >= selectionBounds.minCol && colIndex <= selectionBounds.maxCol) 
                          ? 'bg-indigo-100/60 dark:bg-indigo-900/40 relative after:absolute after:inset-0 after:border after:border-indigo-400 after:pointer-events-none' 
                          : ''
                      }`}
                      title="Double-click to rename column"
                    >
                      {isBeingEdited ? (
                        <div className="flex items-center gap-1.5 h-6">
                          <input 
                            autoFocus
                            autoComplete="off"
                            spellCheck={false}
                            value={editingColName}
                            onChange={e => setEditingColName(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleSaveCol()}
                            onBlur={handleSaveCol}
                            className="bg-transparent border-0 border-transparent p-0 text-slate-900 dark:text-white font-bold text-xs uppercase tracking-wider w-28 focus:outline-none focus:ring-0 focus:border-transparent"
                          />
                          <button onClick={handleSaveCol} className="text-emerald-600 hover:text-emerald-700 transition-colors shrink-0" title="Save column name"><Save className="w-3.5 h-3.5"/></button>
                          <button onClick={handleDeleteCol} className="text-red-500 hover:text-red-600 transition-colors shrink-0" title="Delete column"><Trash2 className="w-3.5 h-3.5"/></button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5">
                            {col.type === 'status' && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,0.5)]"></div>}
                            {col.type === 'phone' && <Phone className="w-3 h-3 text-indigo-500" />}
                            {col.type === 'location' && <MapPin className="w-3 h-3 text-rose-500" />}
                            {col.type === 'driver' && <User className="w-3 h-3 text-blue-500" />}
                            {col.type === 'money' && <IndianRupee className="w-3 h-3 text-emerald-500" />}
                            {col.type === 'date' && <Calendar className="w-3 h-3 text-amber-500" />}
                            {col.type === 'number' && <span className="font-mono text-slate-400 font-bold text-[10px]">#</span>}
                            {col.type === 'tags' && <Tag className="w-3 h-3 text-purple-500" />}
                            {col.type === 'email' && <MessageCircle className="w-3 h-3 text-rose-500" />}
                            <span className={col.type !== 'text' ? 'text-slate-800 dark:text-slate-200 font-bold' : ''}>{col.name}</span>
                          </div>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleStartEditCol(col);
                            }}
                            className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-indigo-500 transition-opacity"
                            title="Rename"
                          >
                            <Edit className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </th>
                  );
                })}
                <th className="p-3 w-10"></th>
              </tr>

            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {/* Insert Row Form */}
              {isAddingRow && (
                <tr className="bg-indigo-50/30 dark:bg-indigo-900/10">
                  <td className="p-2 w-10"></td>
                  {activeTable.columns.map(col => (
                    <td key={col.id} className="p-2">
                      {col.type === 'status' ? (
                        <select
                          value={newRowForm[col.id] || ""}
                          onChange={e => setNewRowForm({...newRowForm, [col.id]: e.target.value})}
                          className="w-full bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2 py-1.5 text-xs text-slate-900 dark:text-slate-100"
                        >
                          <option value="">Select Status</option>
                          <option value="Pending">Pending</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Dispatched">Dispatched</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      ) : (
                        <input 
                          type={col.type === 'date' ? 'date' : col.type === 'number' ? 'number' : 'text'}
                          autoComplete="off"
                          spellCheck={false}
                          placeholder={`Enter ${col.name}...`}
                          value={newRowForm[col.id] || ""}
                          onChange={e => setNewRowForm({...newRowForm, [col.id]: e.target.value})}
                          className="w-full bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 text-xs text-slate-900 dark:text-slate-100"
                        />
                      )}
                    </td>
                  ))}
                  <td className="p-2 text-right">
                    <button onClick={handleAddNewRow} className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded shadow-sm">Save</button>
                  </td>
                </tr>
              )}

              {/* Virtualized Space Top */}
              {rowVirtualizer.getVirtualItems().length > 0 && (
                <tr style={{ height: `${rowVirtualizer.getVirtualItems()[0].start}px` }}></tr>
              )}
              {/* Data Rows */}
              {rowVirtualizer.getVirtualItems().map(virtualRow => {
                const row = filteredRows[virtualRow.index];
                if (!row) return null;
                return (
                  <MemoizedTableRow
                    key={row.id}
                    row={row}
                    activeTable={activeTable}
                    editingRowId={editingRowId}
                    editRowForm={editRowForm}
                    setEditRowForm={setEditRowForm}
                    handleSaveRow={handleSaveRow}
                    setEditingRowId={setEditingRowId}
                    activePhoneMenu={activePhoneMenu}
                    setActivePhoneMenu={setActivePhoneMenu}
                    activeLocationMenu={activeLocationMenu}
                    setActiveLocationMenu={setActiveLocationMenu}
                    handleStartEditRow={handleStartEditRow}
                    openAppModal={openAppModal}
                    handleDeleteAction={handleDeleteAction}
                    isNew={row.id === justAddedRowId}
                    rowIndex={virtualRow.index}
                    selectionBounds={selectionBounds}
                  />
                );
              })}
              {/* Virtualized Space Bottom */}
              {rowVirtualizer.getVirtualItems().length > 0 && (
                <tr style={{ height: `${rowVirtualizer.getTotalSize() - rowVirtualizer.getVirtualItems()[rowVirtualizer.getVirtualItems().length - 1].end}px` }}></tr>
              )}
              {filteredRows.length === 0 && !isAddingRow && (
                <tr>
                  <td colSpan={activeTable.columns.length + 1} className="p-8 text-center text-slate-500 text-sm">
                    No data in this table yet or no matches found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Suspense fallback={<div className="hidden">Loading...</div>}>
        <ExtensionLibraryModal />
      </Suspense>

      {/* Reusable App Modal */}
      {appModalConfig.isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60" onClick={closeAppModal} />
          <div className="relative w-full max-w-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xl rounded-2xl overflow-hidden flex flex-col animate-fadeIn">
            <div className="p-4 border-b border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between">
              <h3 className="font-bold text-slate-800 dark:text-slate-100">{appModalConfig.title}</h3>
              <button onClick={closeAppModal} className="text-slate-400 hover:text-red-500 transition-colors"><X className="w-5 h-5"/></button>
            </div>
            <div className="p-5 flex flex-col gap-4">
              {appModalConfig.message && <p className="text-sm text-slate-600 dark:text-slate-300">{appModalConfig.message}</p>}
              {appModalConfig.type === 'prompt' && (
                <input 
                  type="text"
                  autoFocus
                  placeholder="Enter value..."
                  defaultValue={appModalConfig.inputValue || ""}
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      if (appModalConfig.onConfirm) appModalConfig.onConfirm(e.currentTarget.value);
                      closeAppModal();
                    }
                  }}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 text-slate-800 dark:text-slate-100"
                />
              )}
              <div className="flex justify-end gap-2 mt-2">
                <button 
                  onClick={closeAppModal}
                  className="px-4 py-2 text-sm font-semibold rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button 
                  onClick={(e) => {
                    const input = e.currentTarget.parentElement?.parentElement?.querySelector('input');
                    if (appModalConfig.onConfirm) appModalConfig.onConfirm(appModalConfig.type === 'prompt' ? input?.value : undefined);
                    closeAppModal();
                  }}
                  className={`px-4 py-2 text-sm font-bold rounded-lg text-white transition shadow-sm ${appModalConfig.type === 'confirm' ? 'bg-red-600 hover:bg-red-500' : 'bg-indigo-600 hover:bg-indigo-500'}`}
                >
                  {appModalConfig.type === 'confirm' ? 'Delete' : 'Confirm'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Google Sheets Sync Modal */}
      {showGoogleSheetModal && (
        <div className="fixed inset-0 z-[190] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setShowGoogleSheetModal(false)} />
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl rounded-2xl overflow-hidden flex flex-col animate-fadeIn">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <svg viewBox="0 0 24 24" className="w-5 h-5 text-emerald-600">
                  <path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2m-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2Z"/>
                </svg>
                <h3 className="font-bold text-slate-800 dark:text-slate-100">
                  {googleSheetModalMode === 'import' ? 'Import from Google Sheet' : 'Export to Google Sheet'}
                </h3>
              </div>
              <button onClick={() => setShowGoogleSheetModal(false)} className="text-slate-400 hover:text-red-500 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 flex flex-col gap-4">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {googleSheetModalMode === 'import'
                  ? `Populate "${activeTable.name}" by pulling rows directly from any Google Sheet spreadsheet.`
                  : `Export columns and rows of "${activeTable.name}" directly into a Google Sheet spreadsheet.`
                }
              </p>

              {needsAuth ? (
                <div className="py-6 flex flex-col items-center justify-center text-center gap-4">
                  <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-full">
                    <svg viewBox="0 0 48 48" className="w-10 h-10">
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    </svg>
                  </div>
                  {isIframe ? (
                    <div className="flex flex-col items-center gap-3 bg-amber-500/10 dark:bg-amber-500/5 border border-amber-200 dark:border-amber-900/40 p-4 rounded-xl max-w-sm">
                      <h4 className="text-xs font-bold text-amber-800 dark:text-amber-400 uppercase tracking-wider font-mono">Sandbox Environment Warning</h4>
                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                        To sign in securely using Google Auth, you must open this application in a standalone browser tab. This bypasses security limitations such as blocking of third-party cookies & popups in the preview panel iframe.
                      </p>
                      <button
                        onClick={() => window.open(window.location.href, '_blank')}
                        className="mt-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition shadow-md"
                      >
                        Open App in Standalone Tab — Sign In
                      </button>
                    </div>
                  ) : (
                    <>
                      <div>
                        <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">Google Credentials Required</h4>
                        <p className="text-xs text-slate-500 mt-1 max-w-[280px]">Link your Google Account to authorize file access and Spreadsheet modifications.</p>
                      </div>
                      <button
                        onClick={handleGoogleLogin}
                        disabled={isLoggingIn}
                        className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-sm"
                      >
                        {isLoggingIn ? (
                          <><Loader2 className="w-4 h-4 animate-spin text-white" /> Connecting...</>
                        ) : (
                          <>Sign In with Google</>
                        )}
                      </button>
                    </>
                  )}
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Spreadsheet ID or URL</label>
                    <input 
                      type="text" 
                      placeholder={googleSheetModalMode === 'export' ? "Paste target ID/URL, or leave empty to create..." : "Paste spreadsheet ID or URL..."}
                      value={spreadsheetId}
                      onChange={e => setSpreadsheetId(e.target.value)}
                      className="w-full text-xs font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  {syncStatus && (
                    <div className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/20 px-3 py-2 rounded-lg border border-indigo-100 dark:border-indigo-900/20">
                      Status: {syncStatus}
                    </div>
                  )}

                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 mt-2">
                    <button
                      onClick={() => setShowGoogleSheetModal(false)}
                      className="px-4 py-2 text-xs font-bold text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
                    >
                      Close
                    </button>

                    {googleSheetModalMode === 'import' ? (
                      <button 
                        onClick={async () => {
                          await handleSyncSheet();
                        }}
                        disabled={isConnectingSheet || !spreadsheetId}
                        className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition disabled:opacity-50 shadow-sm"
                      >
                        {isConnectingSheet ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                        <span>Sync/Import</span>
                      </button>
                    ) : (
                      <div className="flex gap-2">
                        <button
                          onClick={async () => {
                            await handleExportToGoogleSheet(false);
                          }}
                          disabled={isConnectingSheet || !spreadsheetId}
                          className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-800 dark:text-slate-200 bg-slate-105 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition disabled:opacity-40"
                        >
                          <Download className="w-3.5 h-3.5 text-slate-500" />
                          <span>Linked Sheet</span>
                        </button>

                        <button
                          onClick={async () => {
                            await handleExportToGoogleSheet(true);
                          }}
                          disabled={isConnectingSheet}
                          className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition disabled:opacity-40 shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Create New</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}


      {/* Snackbar for Undo */}
      {lastAction && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[300] flex items-center justify-between gap-4 px-4 py-3 bg-slate-900 shadow-xl rounded-xl border border-slate-700 sm:mb-0 mb-14 min-w-[280px]"
        >
          <span className="text-white text-sm font-medium">{lastAction}</span>
          <button
            onClick={() => {
              undo();
              clearLastAction();
            }}
            className="text-indigo-400 hover:text-indigo-300 active:text-indigo-200 font-bold tracking-wide uppercase text-xs transition px-2 py-1 rounded"
          >
            Undo
          </button>
        </motion.div>
      )}
    </div>
  );
}
