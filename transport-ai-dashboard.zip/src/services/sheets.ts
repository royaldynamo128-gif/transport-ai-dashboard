export async function fetchSpreadsheet(spreadsheetId: string, range: string, accessToken: string) {
  const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    const message = errorData?.error?.message || 'Failed to fetch spreadsheet data';
    throw new Error(message);
  }
  return await res.json();
}

export async function appendToSpreadsheet(spreadsheetId: string, range: string, values: any[][], accessToken: string) {
  const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED`, {
    method: 'POST',
    headers: { 
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ values })
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    const message = errorData?.error?.message || 'Failed to append to spreadsheet';
    throw new Error(message);
  }
  return await res.json();
}

export async function createSheetTab(spreadsheetId: string, tabTitle: string, headers: string[], accessToken: string) {
  // First, attempt to create the tab
  const addSheetRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      requests: [{
        addSheet: {
          properties: {
            title: tabTitle
          }
        }
      }]
    })
  });
  
  if (!addSheetRes.ok) {
    const errorData = await addSheetRes.json().catch(() => ({}));
    const message = errorData?.error?.message || '';
    // If it already exists, we can ignore the creation error
    if (!message.includes('already exists')) {
      throw new Error(`Failed to create tab: ${message}`);
    }
  }

  // Then, set the headers if provided
  if (headers && headers.length > 0) {
    const updateRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${tabTitle}!A1:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: [headers] })
    });
    
    if (!updateRes.ok) {
      const errorData = await updateRes.json().catch(() => ({}));
      throw new Error(errorData?.error?.message || 'Failed to write headers');
    }
  }
}

export async function createSpreadsheet(title: string, accessToken: string) {
  const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: title
      }
    })
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || 'Failed to create new spreadsheet');
  }
  return await res.json();
}

export async function updateSpreadsheetValues(spreadsheetId: string, range: string, values: any[][], accessToken: string) {
  const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}?valueInputOption=USER_ENTERED`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      values: values
    })
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || 'Failed to update spreadsheet cells');
  }
  return await res.json();
}

