import { collection, doc, setDoc, deleteDoc, updateDoc, onSnapshot, query, where, serverTimestamp, limit } from 'firebase/firestore';
import { db, auth } from './firebase';
import { Booking } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function subscribeToBookings(onBookingsChanged: (bookings: Booking[]) => void) {
  const user = auth.currentUser;
  if (!user) return () => {};
  
  const bookingsQuery = query(collection(db, 'bookings'), where('userId', '==', user.uid), limit(500));
  
  return onSnapshot(bookingsQuery, (snapshot) => {
    const data: Booking[] = [];
    snapshot.forEach((doc) => {
      data.push(doc.data() as Booking);
    });
    // Sort descending by timestamp text (for simplicity we just rely on doc data insertion order or re-sort later)
    onBookingsChanged(data);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, 'bookings');
  });
}

export async function addBooking(booking: Booking) {
  const user = auth.currentUser;
  if (!user) throw new Error("Must be logged in.");
  
  try {
    const payload = {
      ...booking,
      userId: user.uid,
      createdAt: serverTimestamp()
    };
    await setDoc(doc(db, 'bookings', booking.id), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `bookings/${booking.id}`);
  }
}

export async function updateBooking(bookingId: string, modifications: Partial<Booking>) {
  try {
    const payload = {
      ...modifications,
      updatedAt: serverTimestamp()
    };
    await updateDoc(doc(db, 'bookings', bookingId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `bookings/${bookingId}`);
  }
}

export async function deleteBooking(bookingId: string) {
  try {
    await deleteDoc(doc(db, 'bookings', bookingId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `bookings/${bookingId}`);
  }
}
