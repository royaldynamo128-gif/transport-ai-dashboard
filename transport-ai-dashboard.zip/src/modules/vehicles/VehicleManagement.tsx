import React from 'react';
import { useVehicleStore } from '../../store/vehicleStore';
import { Truck, Plus, FileText, AlertCircle } from 'lucide-react';

export function VehicleManagement() {
  const { vehicles } = useVehicleStore();

  return (
    <div className="flex flex-col h-full gap-6 animate-fadeIn">
      {/* Header section */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Truck className="w-6 h-6 text-emerald-500" />
            Vehicle Fleet
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage trucks, track insurance, fitness expiries, and vehicle statuses.
          </p>
        </div>
        <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" />
          Add Vehicle
        </button>
      </div>

      {/* Main Content: Vehicle List */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden flex-1 flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-6 py-4">Registration</th>
                <th className="px-6 py-4">Type & Capacity</th>
                <th className="px-6 py-4">Expiries (Fitness/Ins.)</th>
                <th className="px-6 py-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {vehicles.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-slate-500">
                    No vehicles found. Click "Add Vehicle" to register one.
                  </td>
                </tr>
              ) : (
                vehicles.map((vehicle) => (
                  <tr key={vehicle.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group cursor-pointer">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-900 dark:text-slate-100 font-mono">
                        {vehicle.registrationNumber}
                      </div>
                      {vehicle.extraNotes && (
                        <div className="text-xs text-slate-500 mt-1 flex items-start gap-1">
                          <FileText className="w-3 h-3 mt-[2px] shrink-0" />
                          <span className="truncate max-w-[250px]">{vehicle.extraNotes}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-slate-900 dark:text-slate-200">{vehicle.type}</div>
                      <div className="text-xs text-slate-500">{vehicle.capacity || 'Unknown Capacity'}</div>
                    </td>
                    <td className="px-6 py-4">
                       <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2 text-xs">
                           <span className="w-16 text-slate-400">Fitness:</span>
                           {vehicle.fitnessExpiry ? <span>{vehicle.fitnessExpiry}</span> : <span className="text-amber-500 flex items-center gap-1"><AlertCircle className="w-3 h-3"/> Missing</span>}
                        </div>
                        <div className="flex items-center gap-2 text-xs">
                           <span className="w-16 text-slate-400">Insurance:</span>
                           {vehicle.insuranceExpiry ? <span>{vehicle.insuranceExpiry}</span> : <span className="text-amber-500 flex items-center gap-1"><AlertCircle className="w-3 h-3"/> Missing</span>}
                        </div>
                       </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border
                        ${vehicle.status === 'Available' ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20' : 
                          vehicle.status === 'On Trip' ? 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/10 dark:text-blue-400 dark:border-blue-500/20' : 
                          vehicle.status === 'Under Repair' ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/20' :
                          'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'}
                      `}>
                        {vehicle.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
