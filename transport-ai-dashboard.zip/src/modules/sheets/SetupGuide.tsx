import React, { useState } from "react";
import { Check, Clipboard, Settings, HelpCircle, Code, ArrowRight, ExternalLink, Database, Cpu, Milestone, Activity, RefreshCw, CheckCircle2, XCircle, AlertTriangle } from "lucide-react";
import { useTableStore } from "../../store/tableStore";

export function SetupGuide() {
  const customTables = useTableStore(state => state.customTables);
  // Config variables
  const [sheetsUrl, setSheetsUrl] = useState("https://docs.google.com/spreadsheets/d/1WjocRlNpQ7rvbCn8t7O2du-R5Y1fZxdus3iksU2w5qc/edit");
  const [sheetName, setSheetName] = useState("Bookings");
  const [phoneId, setPhoneId] = useState("1155288394331320");
  const [verifyToken, setVerifyToken] = useState("transport_ai_123");
  const [whatsappToken, setWhatsappToken] = useState("EAAVQL8y8C88BRowKJABZAZCeOqyCWx35DmrtzsLybORdSTgwcy66HuqSHkdSrcdYx4LOazl6nLZC2EwZAsmZAaJq5AvQpfDCwCZAZCIG4ZCevVdyG6ZB7WZCci0SxcimMEnZB7cxpQPrRQEIsbGJde3tT6kwxyA7jclodCNjTRW6IYl2KR3U40x5d0ZBnHTRKp0OtCWGOouDHQo5bVxSX5P0Vk2RjZCeRYrZAqwsOHMf3k0UFFX2rwu2xWX4ZBTGU1ZCmcfQZBhmi2UvE75csCDYdKcOptcXme9b3");
  const [geminiApiKey, setGeminiApiKey] = useState("AIzaSyAWsBM9H7QJYNpxWPsat2xs6Y-8p2W4WRk");
  const [appsScriptUrl, setAppsScriptUrl] = useState("");

  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<"step1" | "step2" | "step3">("step1");
  const [copiedType, setCopiedType] = useState<string | null>(null);
  
  const [pingStatus, setPingStatus] = useState<"idle" | "testing" | "success" | "error">("idle");
  const [pingMessage, setPingMessage] = useState("");

  const handlePingTest = async () => {
    setPingStatus("testing");
    setPingMessage("");
    try {
      const challenge = "test_challenge_" + Date.now();
      const url = new URL("/api/webhook", window.location.origin);
      url.searchParams.set("hub.mode", "subscribe");
      url.searchParams.set("hub.verify_token", verifyToken);
      url.searchParams.set("hub.challenge", challenge);

      const response = await fetch(url.toString(), {
        method: "GET",
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${await response.text()}`);
      }

      const text = await response.text();
      if (text === challenge) {
        setPingStatus("success");
      } else {
        throw new Error(`Challenge mismatch. Expected ${challenge}, got ${text}`);
      }
    } catch (e: any) {
      setPingStatus("error");
      setPingMessage(e.message || "Unknown error");
    }
  };

  const handleSaveConfig = async () => {
    setIsSaving(true);
    try {
      await fetch("/api/save-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          WHATSAPP_TOKEN: whatsappToken,
          PHONE_ID: phoneId,
          VERIFY_TOKEN: verifyToken,
          SHEETS_WEBHOOK_URL: appsScriptUrl,
          GEMINI_API_KEY: geminiApiKey,
        })
      });
      alert("Configuration activated! The AI Studio server is now acting as your real, live WhatsApp Webhook.");
    } catch (e) {
      alert("Failed to save configuration.");
    }
    setIsSaving(false);
  };

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  // Google Apps Script template generator
  const getAppsScriptCode = () => {
    return [
      '// ====================================================',
      '// TRANSPORT ERP - Google Apps Script (Webhook)',
      '// ====================================================',
      '// Paste this code in Extensions -> Apps Script',
      '// Name the file Code.gs, then Deploy -> New Deployment -> Web app',
      '// Set "Who has access" to "Anyone"',
      '',
      `const SHEET_NAME = "${sheetName.trim() || 'Bookings'}";`,
      '',
      'function doPost(e) {',
      '  try {',
      '    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);',
      '    if (!sheet) {',
      '      return ContentService.createTextOutput(JSON.stringify({',
      '        success: false,',
      '        error: "Sheet not found: " + SHEET_NAME',
      '      })).setMimeType(ContentService.MimeType.JSON);',
      '    }',
      '',
      '    const data = JSON.parse(e.postData.contents);',
      '',
      '    // READ mode for filtering/fetching records',
      '    if (data.action === "read") {',
      '       const rows = sheet.getDataRange().getValues();',
      '       if (rows.length < 2) return ContentService.createTextOutput(JSON.stringify({ success: true, data: [] })).setMimeType(ContentService.MimeType.JSON);',
      '       const headers = rows[0];',
      '       const queryData = rows.slice(1).map(row => {',
      '          let obj = {};',
      '          headers.forEach((h, i) => obj[h.toString().toLowerCase()] = row[i]);',
      '          return obj;',
      '       });',
      '       ',
      '       let filtered = queryData;',
      '       if (data.customer) filtered = filtered.filter(r => r["customer"]?.toString().toLowerCase().includes(data.customer.toLowerCase()));',
      '       if (data.pickup) filtered = filtered.filter(r => r["pickup"]?.toString().toLowerCase().includes(data.pickup.toLowerCase()));',
      '       if (data.destination) filtered = filtered.filter(r => r["destination"]?.toString().toLowerCase().includes(data.destination.toLowerCase()));',
      '       ',
      '       return ContentService.createTextOutput(JSON.stringify({',
      '         success: true,',
      '         data: filtered.slice(-10) // Return up to 10 latest matches',
      '       })).setMimeType(ContentService.MimeType.JSON);',
      '    }',
      '',
      '    // WRITE mode (default)',
      '    const timestamp = new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" });',
      '',
      '    sheet.appendRow([',
      '      "BK" + new Date().getTime().toString().slice(-8),',
      '      timestamp,',
      '      data.customer || "",',
      '      data.pickup || "",',
      '      data.destination || "",',
      '      data.material || "",',
      '      data.weight || "",',
      '      data.truck_type || "",',
      '      data.rate || "",',
      '      "Pending",',
      '      "via WhatsApp"',
      '    ]);',
      '',
      '    return ContentService.createTextOutput(JSON.stringify({',
      '      success: true,',
      '      message: "Row appended successfully"',
      '    })).setMimeType(ContentService.MimeType.JSON);',
      '',
      '  } catch (err) {',
      '    return ContentService.createTextOutput(JSON.stringify({',
      '      success: false,',
      '      error: err.toString()',
      '    })).setMimeType(ContentService.MimeType.JSON);',
      '  }',
      '}',
      '',
      'function testPost() {',
      '  doPost({ postData: { contents: JSON.stringify({ action: "read", customer: "Tata" }) } });',
      '}'
    ].join('\\n');
  };

  // Cloudflare Worker Bot generator (Live Webhook logic with Gemini)
  const getWorkerCode = () => {
    const aiStudioWebhookUrl = window.location.origin + "/api/webhook";
    
    return [
      `const AI_STUDIO_WEBHOOK_URL = "${aiStudioWebhookUrl}";`,
      '',
      'export default {',
      '  async fetch(request, env) {',
      '    const VERIFY_TOKEN = env.VERIFY_TOKEN;',
      '    if (!VERIFY_TOKEN) return new Response("Missing VERIFY_TOKEN secret", { status: 500 });',
      '',
      '    const url = new URL(request.url);',
      '',
      '    // Meta webhook verification (GET)',
      '    if (request.method === "GET") {',
      '      const mode = url.searchParams.get("hub.mode");',
      '      const token = url.searchParams.get("hub.verify_token");',
      '      const challenge = url.searchParams.get("hub.challenge");',
      '',
      '      if (mode === "subscribe" && token === VERIFY_TOKEN) {',
      '        return new Response(challenge, { status: 200 });',
      '      }',
      '      return new Response("Forbidden", { status: 403 });',
      '    }',
      '',
      '    // Proxy message delivery (POST) to AI Studio',
      '    if (request.method === "POST") {',
      '      try {',
      '        const body = await request.arrayBuffer();',
      '        const response = await fetch(AI_STUDIO_WEBHOOK_URL + url.search, {',
      '          method: "POST",',
      '          headers: {',
      '            "Content-Type": request.headers.get("Content-Type") || "application/json",',
      '          },',
      '          body,',
      '        });',
      '',
      '        const responseBody = await response.text();',
      '        return new Response(responseBody, {',
      '          status: response.status,',
      '          headers: { "Content-Type": response.headers.get("Content-Type") || "application/json" },',
      '        });',
      '      } catch (err) {',
      '        console.error("Proxy error:", err);',
      '        return new Response("Internal Server Error", { status: 500 });',
      '      }',
      '    }',
      '',
      '    return new Response("Method Not Allowed", { status: 405 });',
      '  },',
      '};'
    ].join('\n');
  };



  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200.5 dark:border-slate-800 rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] font-sans overflow-hidden">
      
      {/* Parameter Injection Configuration Panel */}
      <div className="bg-slate-50 dark:bg-[#0f172b] border-b border-slate-150 dark:border-slate-800 p-5 select-none relative">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Settings className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span>Live Bot Configuration (Make It Real)</span>
          </h3>
          <div className="flex items-center gap-3">
            <button 
              onClick={handleSaveConfig}
              disabled={isSaving}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-1.5 px-4 rounded-lg transition disabled:opacity-50"
            >
              {isSaving ? "Saving..." : "Save Configuration to Server"}
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
          {/* Column 1: Sheets */}
          <div className="bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200/60 dark:border-slate-700/60 flex flex-col gap-2.5">
            <span className="font-bold text-emerald-800 dark:text-emerald-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-700/50 pb-1.5">
              <Database className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-500" />
              <span>1. Google Sheets Config</span>
            </span>
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase mb-1">Spreadsheet URL</label>
              <input
                type="text"
                value={sheetsUrl}
                onChange={(e) => setSheetsUrl(e.target.value)}
                className="w-full text-[11px] font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:focus:ring-indigo-400 text-slate-900 dark:text-slate-100 select-all"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase mb-1">Sheet name</label>
              <input
                type="text"
                value={sheetName}
                onChange={(e) => setSheetName(e.target.value)}
                className="w-full text-xs font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:focus:ring-indigo-400 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Column 2: Meta API */}
          <div className="bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200/60 dark:border-slate-700/60 flex flex-col gap-2.5">
            <span className="font-bold text-teal-850 dark:text-teal-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-700/50 pb-1.5">
              <Code className="w-3.5 h-3.5 text-teal-600 dark:text-teal-500" />
              <span>2. WhatsApp Cloud API</span>
            </span>
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase mb-1">WhatsApp Phone ID</label>
              <input
                type="text"
                value={phoneId}
                onChange={(e) => setPhoneId(e.target.value)}
                className="w-full text-[11px] font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:focus:ring-indigo-400 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase mb-1">Webhook Verify Token</label>
              <input
                type="text"
                value={verifyToken}
                onChange={(e) => setVerifyToken(e.target.value)}
                className="w-full text-xs font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:focus:ring-indigo-400 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Column 3: Keys */}
          <div className="bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200/60 dark:border-slate-700/60 flex flex-col gap-2.5">
            <span className="font-bold text-indigo-900 dark:text-indigo-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-700/50 pb-1.5">
              <Cpu className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-500" />
              <span>3. External Integrations</span>
            </span>
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase mb-1">Gemini API Key</label>
              <input
                type="password"
                placeholder="AIzaSy... (obtained in Part 2)"
                value={geminiApiKey}
                onChange={(e) => setGeminiApiKey(e.target.value)}
                className="w-full text-xs font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:focus:ring-indigo-400 text-slate-900 dark:text-slate-100 select-all"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase mb-1">Apps Script Web App URL</label>
              <input
                type="text"
                placeholder="https://script.google.com/macros/s/.../exec"
                value={appsScriptUrl}
                onChange={(e) => setAppsScriptUrl(e.target.value)}
                className="w-full text-[11px] font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:focus:ring-indigo-400 text-slate-900 dark:text-slate-100 select-all"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Steps Navigation Tabs */}
      <div className="flex bg-slate-100/50 dark:bg-slate-800/30 border-b border-slate-200 dark:border-slate-700/50 overflow-x-auto select-none">
        <button
          onClick={() => setActiveTab("step1")}
          className={`flex-1 min-w-[200px] text-center py-3 px-4 text-xs font-semibold border-b-2 flex items-center justify-center gap-2 cursor-pointer transition ${
            activeTab === "step1"
              ? "border-emerald-600 text-emerald-800 dark:text-[#00d492] bg-white dark:bg-[#0f172b] focus:outline-none"
              : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50 focus:outline-none"
          }`}
        >
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-[#00d492] text-[10px]">1</span>
          <span>Google Apps Script (Sheet Bridge)</span>
        </button>
        <button
          onClick={() => setActiveTab("step2")}
          className={`flex-1 min-w-[200px] text-center py-3 px-4 text-xs font-semibold border-b-2 flex items-center justify-center gap-2 cursor-pointer transition ${
            activeTab === "step2"
              ? "border-teal-700 text-teal-800 dark:text-[#00d492] bg-white dark:bg-[#0f172b] focus:outline-none"
              : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50 focus:outline-none"
          }`}
        >
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-900/30 text-teal-800 dark:text-[#00d492] text-[10px]">2</span>
          <span>Get Free Gemini Key</span>
        </button>
        <button
          onClick={() => setActiveTab("step3")}
          className={`flex-1 min-w-[200px] text-center py-3 px-4 text-xs font-semibold border-b-2 flex items-center justify-center gap-2 cursor-pointer transition ${
            activeTab === "step3"
              ? "border-indigo-650 text-indigo-800 dark:text-[#00d492] bg-white dark:bg-[#0f172b] focus:outline-none"
              : "border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50 focus:outline-none"
          }`}
        >
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-[#00d492] text-[10px]">3</span>
          <span>Cloudflare Worker Bot Script</span>
        </button>
      </div>

      {/* Tab Panels Contents */}
      <div className="p-6 dark:bg-[#0f172b]">
        
        {/* Step 1: Apps Script */}
        {activeTab === "step1" && (
          <div className="flex flex-col gap-4 font-sans">
            <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 text-emerald-950 dark:bg-[#0f172b] dark:border-slate-800 dark:text-[#00d492] text-xs leading-relaxed">
              <h4 className="font-bold text-sm mb-1 text-emerald-900 dark:text-[#00d492]">Sheet Bridge Webhook setup</h4>
              This script lets your Google Sheet securely accept data from the WhatsApp bot of Cloudflare, appending bookings as raw structural rows automatically in Indian Timezone.
            </div>

            <div className="text-xs">
              <h4 className="font-bold text-slate-850 mb-2">Instructions:</h4>
              <ol className="list-decimal pl-5 flex flex-col gap-1.5 text-slate-600">
                <li>Open your Google Sheet (e.g., <span className="font-mono bg-slate-100 text-slate-700 px-1 py-0.2 rounded">Transport Database</span>).</li>
                <li>Make sure you have a sheet tab named **"{sheetName}"** with columns in order: <span className="font-mono bg-slate-100 text-slate-700 px-1 text-[10px] rounded">Booking ID, Date, Customer, Pickup, Destination, Material, Weight, Truck Type, Rate, Status, Source</span>.</li>
                <li>Click <strong>Extensions</strong> → <strong>Apps Script</strong>.</li>
                <li>Delete any legacy placeholder functions and paste the generated script below.</li>
                <li>Click <strong>Deploy</strong> → <strong>New Deployment</strong>.</li>
                <li>Choose type: <strong>Web app</strong>. Execute as: <span className="underline">Me</span>. Who has access: <span className="underline">Anyone</span>.</li>
                <li>Click <strong>Deploy</strong>, authorize permissions, and copy the <strong>Web App URL</strong> inside the configuration block above!</li>
              </ol>
            </div>

            <div className="relative mt-2">
              <div className="flex items-center justify-between bg-slate-850 text-slate-350 text-[10px] uppercase font-bold py-1.8 px-4 rounded-t-xl border-b border-slate-750">
                <span>Google Apps Script - Code Sheet Code</span>
                <button
                  onClick={() => handleCopy(getAppsScriptCode(), "gas")}
                  className="flex items-center gap-1 hover:text-white transition cursor-pointer text-xs"
                >
                  {copiedType === "gas" ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Clipboard className="w-3.5 h-3.5" />
                      <span>Copy Template</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="bg-slate-900 border border-slate-800 text-indigo-150 p-4 rounded-b-xl text-xs font-mono select-all overflow-x-auto max-h-[300px]">
                {getAppsScriptCode()}
              </pre>
            </div>
          </div>
        )}

        {/* Step 2: Gemini Key */}
        {activeTab === "step2" && (
          <div className="flex flex-col gap-4 font-sans text-xs">
            <div className="bg-teal-50 border border-teal-100 rounded-xl p-4 text-teal-950 leading-relaxed">
              <h4 className="font-bold text-sm mb-1 text-teal-900">Extract WhatsApp messages using Gemini</h4>
              Gemini model is used by the bot to extract unstructured WhatsApp sentences into key-value JSON parameters, like origin city, truck types, materials, and rates.
            </div>

            <div>
              <h4 className="font-bold text-slate-850 mb-2">How to grab your token:</h4>
              <ol className="list-decimal pl-5 flex flex-col gap-2 text-slate-600">
                <li>
                  Go to{" "}
                  <a
                    href="https://aistudio.google.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-indigo-650 hover:underline font-semibold inline-flex items-center gap-0.5"
                  >
                    Google AI Studio <ExternalLink className="w-3 h-3 inline" />
                  </a>.
                </li>
                <li>Click the top-left <strong>Create API Key</strong> button.</li>
                <li>Choose or create a project, then copy your unique API Token (looks like <code className="font-mono bg-slate-100 px-1 py-0.2 rounded text-rose-600">AIzaSy...</code>).</li>
                <li>Paste it in the <strong className="text-indigo-900">Interactive Exporter</strong> panel above to automatically inject it into variables before downloading scripts!</li>
              </ol>
            </div>

            {/* Note about built-in keys inside workspace template */}
            <div className="bg-amber-50/50 border border-amber-100/80 p-3.5 rounded-xl text-[11px] text-amber-900">
              💡 <strong>Developer Note:</strong> For this workspace simulator, we utilize the server-side Gemini execution key configured in your AI Studio secrets automatically. Try testing the bot directly inside the Live Simulator tab!
            </div>
          </div>
        )}

        {/* Step 3: Cloudflare Bot script */}
        {activeTab === "step3" && (
          <div className="flex flex-col gap-4 font-sans">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-950 text-xs leading-relaxed">
              <h4 className="font-bold text-sm mb-1 text-amber-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" /> 
                Sandbox Constraint: Use Cloudflare Workers
              </h4>
              AI Studio preview URLs (<code>https://ais-dev-...</code>) are protected by a Google security proxy. <strong>Meta's WhatsApp servers cannot bypass this proxy</strong>, so putting your AI Studio URL directly into Meta's dashboard will always fail verification. <br/><br/>
              To make the bot run <strong>LIVE</strong> right now, deploy the stateless connection layer to a free Cloudflare Worker using the code below.
            </div>

            <div className="text-xs">
              <h4 className="font-bold text-slate-850 mb-2">Cloudflare Worker Edge Deployment Setup:</h4>
              <ol className="list-decimal pl-5 flex flex-col gap-2.5 text-slate-600">
                <li>Create a free <a href="https://workers.cloudflare.com/" target="_blank" rel="noreferrer" className="text-indigo-600 underline">Cloudflare Worker</a>.</li>
                <li>Click <strong>Edit Code</strong> and paste the <span className="font-mono bg-slate-100 text-slate-800 px-1 py-0.5 rounded font-bold">Cloudflare Worker Bot Code</span> (found below) into the editor.</li>
                <li>Ensure you have hit the <strong>Save Configuration</strong> button on this page first so the code has your tokens.</li>
                <li>Click <strong>Deploy</strong> in Cloudflare. It will give you a public URL (e.g. <code>https://my-bot.yourname.workers.dev</code>).</li>
                <li><strong>Important:</strong> Go to your Worker Settings → Variables and add a Secret called <code>VERIFY_TOKEN</code> with value <span className="font-mono bg-slate-100 text-slate-800 px-1 py-0.5 rounded font-bold">{verifyToken}</span>.</li>
                <li>Go to your WhatsApp Meta Developer Portal → Configuration.</li>
                <li>Edit Webhook and paste your <strong>Cloudflare Worker URL</strong> there.</li>
                <li>Use Verify Token: <span className="font-mono bg-slate-100 text-slate-800 px-1 py-0.5 rounded font-bold">{verifyToken}</span></li>
              </ol>
            </div>

            {/* Ping Diagnostic Tool */}
            <div className="mt-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-4 shadow-sm">
              <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100 mb-2 flex items-center gap-2">
                <Activity className="w-4 h-4 text-sky-500" />
                Webhook Connectivity Diagnostic
              </h4>
              <p className="text-slate-500 dark:text-slate-400 mb-3">
                Before verifying in Meta's dashboard, test if your Live Bot Server is responding to verification challenges correctly with the token: <strong>{verifyToken}</strong>
              </p>
              <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                <button
                  onClick={handlePingTest}
                  disabled={pingStatus === "testing"}
                  className="flex items-center justify-center gap-2 bg-slate-800 dark:bg-indigo-600 hover:bg-slate-900 dark:hover:bg-indigo-700 border border-slate-700 dark:border-indigo-500 text-white px-4 py-2 rounded-lg font-bold transition disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${pingStatus === "testing" ? "animate-spin" : ""}`} />
                  Run Ping Test
                </button>
                
                {pingStatus === "success" && (
                  <div className="flex flex-col gap-2 mt-2 sm:mt-0">
                    <div className="flex items-center gap-1.5 text-emerald-700 font-bold bg-emerald-50 px-3 py-2 rounded-lg border border-emerald-200 text-xs">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      Success! Internal Webhook is running.
                    </div>
                    <div className="text-xs text-amber-800 bg-amber-50 border border-amber-200 p-2 rounded-lg">
                      <strong>⚠️ Note:</strong> Even though it works internally, Meta cannot reach it because of the Sandbox proxy. Proceed to the Cloudflare Worker setup below!
                    </div>
                  </div>
                )}
                {pingStatus === "error" && (
                   <div className="flex items-center gap-1.5 text-rose-700 font-bold bg-rose-50 px-3 py-2 rounded-lg border border-rose-200 text-xs">
                    <XCircle className="w-4 h-4 text-rose-500" />
                    Failed: {pingMessage}
                  </div>
                )}
              </div>
            </div>

            <div className="relative mt-4">
              <div className="flex items-center justify-between bg-slate-800 text-slate-300 text-xs font-bold py-2 px-4 rounded-t-xl border-b border-slate-700">
                <span className="flex items-center gap-2"><Code className="w-4 h-4 text-indigo-400" /> Cloudflare Worker Bot Code</span>
                <button
                  onClick={() => handleCopy(getWorkerCode(), "worker")}
                  className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-3 py-1.5 transition-colors shadow-sm"
                >
                  {copiedType === "worker" ? (
                    <>
                      <Check className="w-4 h-4 text-white" />
                      <span className="text-white">Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Clipboard className="w-4 h-4" />
                      <span>Copy Full Code</span>
                    </>
                  )}
                </button>
              </div>
              <pre className="bg-[#0b101e] border-x border-b border-[#0b101e] text-indigo-150 p-4 rounded-b-xl text-xs font-mono select-all overflow-x-auto max-h-[400px]">
                {getWorkerCode()}
              </pre>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
