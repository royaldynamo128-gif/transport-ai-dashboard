import React, { useEffect, useState } from "react";
import { MessageCircle, Webhook, RefreshCw, Smartphone, Hash, Navigation } from "lucide-react";

export function WebhookViewer() {
  const [messages, setMessages] = useState<any[]>([]);
  const [bookings, setBookings] = useState<any[]>([]);
  const [isPolling, setIsPolling] = useState(true);

  useEffect(() => {
    let interval: any;
    if (isPolling) {
      interval = setInterval(async () => {
        try {
          const [msgRes, bookingsRes] = await Promise.all([
            fetch("/api/live-messages"),
            fetch("/api/live-bookings")
          ]);
          const msgData = await msgRes.json();
          const bookingsData = await bookingsRes.json();
          setMessages(msgData || []);
          setBookings(bookingsData || []);
        } catch (e) {
          console.error("Failed to fetch live webhooks", e);
        }
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [isPolling]);

  return (
    <div className="flex flex-col h-full gap-6 animate-fadeIn">
      {/* Header section */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Webhook className="w-6 h-6 text-teal-500" />
            Live Webhooks Monitor
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Real-time feed of messages received from Meta WhatsApp API.
          </p>
        </div>
        <button 
          onClick={() => setIsPolling(!isPolling)}
          className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
            isPolling ? "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400 border border-teal-200 dark:border-teal-800" 
            : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
          }`}
        >
          <RefreshCw className={`w-4 h-4 ${isPolling ? "animate-spin" : ""}`} />
          {isPolling ? "Listening Live..." : "Paused"}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full min-h-[500px]">
        {/* Raw Messages List */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-slate-500" />
            <h3 className="font-semibold text-slate-700 dark:text-slate-200 text-sm">Raw WhatsApp Payloads</h3>
            <span className="ml-auto text-xs font-mono bg-slate-200 dark:bg-slate-800 px-2 py-0.5 rounded-full text-slate-600 dark:text-slate-400">
              {messages.length} received
            </span>
          </div>
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 max-h-[500px]">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 gap-2">
                <Smartphone className="w-8 h-8 opacity-50" />
                <p className="text-sm">No live messages received yet.</p>
                <p className="text-xs max-w-[250px] text-center opacity-70">
                  Send a message to your WhatsApp bot number and it will appear here instantly.
                </p>
              </div>
            ) : (
              [...messages].reverse().filter(Boolean).map((msg, idx) => (
                <div key={msg.id || idx} className="bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono text-teal-600 dark:text-teal-400 font-semibold">{msg.sender || "Unknown"}</span>
                    <span className="text-[10px] text-slate-400">{msg.timestamp || ""}</span>
                  </div>
                  <p className="text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap">{msg.text || ""}</p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Extracted Bookings List */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center gap-2">
            <Webhook className="w-4 h-4 text-slate-500" />
            <h3 className="font-semibold text-slate-700 dark:text-slate-200 text-sm">Parsed AI Entities</h3>
            <span className="ml-auto text-xs font-mono bg-slate-200 dark:bg-slate-800 px-2 py-0.5 rounded-full text-slate-600 dark:text-slate-400">
              {bookings.length} processed
            </span>
          </div>
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 max-h-[500px]">
            {bookings.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 gap-2">
                <Hash className="w-8 h-8 opacity-50" />
                <p className="text-sm">No structured data extracted.</p>
              </div>
            ) : (
              [...bookings].reverse().filter(Boolean).map((b, idx) => (
                <div key={b.id || idx} className="bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 rounded-lg p-3 text-sm">
                  <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-200 dark:border-slate-700/50">
                    <span className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400">{b.id || "Unknown"}</span>
                    <span className="text-[10px] text-slate-500">{b.date || ""}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-xs">
                    <div><span className="text-slate-500">Customer:</span> <strong className="text-slate-800 dark:text-slate-200">{b.customer || "—"}</strong></div>
                    <div className="col-span-2 flex items-center gap-1">
                      <Navigation className="w-3 h-3 text-emerald-500" />
                      <strong className="text-slate-800 dark:text-slate-200">{b.pickup || "—"}</strong>
                      <span className="text-slate-400 mx-1">→</span>
                      <strong className="text-slate-800 dark:text-slate-200">{b.destination || "—"}</strong>
                    </div>
                    <div><span className="text-slate-500">Material:</span> <span className="text-slate-700 dark:text-slate-300">{b.material || "—"}</span></div>
                    <div><span className="text-slate-500">Weight:</span> <span className="text-slate-700 dark:text-slate-300">{b.weight || "—"}</span></div>
                    <div><span className="text-slate-500">Truck:</span> <span className="text-slate-700 dark:text-slate-300">{b.truckType || "—"}</span></div>
                    <div><span className="text-slate-500">Rate:</span> <strong className="text-slate-800 dark:text-slate-200">₹{b.rate || "—"}</strong></div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
