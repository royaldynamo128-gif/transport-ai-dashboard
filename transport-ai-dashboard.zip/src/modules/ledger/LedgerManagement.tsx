import React from 'react';
import { useLedgerStore } from '../../store/ledgerStore';
import { BookOpen, Plus, IndianRupee, ArrowDownRight, ArrowUpRight, Copy } from 'lucide-react';
import { format } from 'date-fns';

export function LedgerManagement() {
  const { transactions } = useLedgerStore();

  const getTransactionColor = (type: string) => {
    // Determine visual indicator (red for outgoing, green for incoming, etc. depends on context, but let's use safe generic colors for now)
    if (type.includes('PAYMENT_RECEIVED') || type.includes('FREIGHT_BILLED')) {
      return 'text-emerald-600 bg-emerald-50 border-emerald-200 dark:text-emerald-400 dark:bg-emerald-500/10 dark:border-emerald-500/20';
    }
    return 'text-amber-600 bg-amber-50 border-amber-200 dark:text-amber-400 dark:bg-amber-500/10 dark:border-amber-500/20';
  };

  const getTransactionIcon = (type: string) => {
    if (type.includes('PAYMENT_RECEIVED') || type.includes('FREIGHT_BILLED')) {
      return <ArrowDownRight className="w-4 h-4 text-emerald-500" />;
    }
    return <ArrowUpRight className="w-4 h-4 text-amber-500" />;
  };

  return (
    <div className="flex flex-col h-full gap-6 animate-fadeIn">
      {/* Header section */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-indigo-500" />
            Transaction Ledger
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Immutable log of all financial transactions, driver advances, and freight invoices.
          </p>
        </div>
        <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" />
          Manual Entry
        </button>
      </div>

      {/* Main Content: Ledger List */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden flex-1 flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-6 py-4">Transaction ID</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Ref & Remarks</th>
                <th className="px-6 py-4 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-500">
                    No transactions found.
                  </td>
                </tr>
              ) : (
                transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-slate-900 dark:text-slate-100">{tx.id}</span>
                        <Copy className="w-3 h-3 text-slate-400 hover:text-slate-600 cursor-pointer" />
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-slate-900 dark:text-slate-100">
                        {format(new Date(tx.date), 'dd MMM yyyy')}
                      </div>
                      <div className="text-xs text-slate-500">
                        {format(new Date(tx.date), 'hh:mm a')}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${getTransactionColor(tx.type)}`}>
                        {getTransactionIcon(tx.type)}
                        {tx.type.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-slate-900 dark:text-slate-200">
                        {tx.paymentMethod} {tx.referenceNumber ? `• ${tx.referenceNumber}` : ''}
                      </div>
                      {tx.remarks && (
                        <div className="text-xs text-slate-500 mt-1 max-w-[250px] truncate">
                          {tx.remarks}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 font-mono font-bold text-right text-slate-900 dark:text-slate-100">
                      <div className="flex items-center justify-end gap-1">
                        <IndianRupee className="w-3.5 h-3.5 text-slate-400" />
                        {tx.amount.toLocaleString('en-IN')}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
