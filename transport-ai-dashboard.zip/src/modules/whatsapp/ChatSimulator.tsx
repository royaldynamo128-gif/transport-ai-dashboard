import React, { useRef, useEffect } from "react";
import { Send, CheckCheck, Landmark, Smartphone, RefreshCw, Cpu, Database, AlertCircle, Info, FileCode, CheckCircle, Sparkles, HelpCircle } from "lucide-react";
import { ChatMessage, Booking, CustomTable } from "../../types";
import { useAiStore } from "../../store/aiStore";
import { useTableStore } from "../../store/tableStore";

interface ChatSimulatorProps {
  geminiConfigured: boolean;
}

const TEMPLATE_PROMPTS = [
  {
    title: "Tata Steel (Hinglish)",
    text: "Bhai Tata Steel ke liye booking, Delhi se Pune, iron rods 25 ton, trailer chahiye, rate 45000."
  },
  {
    title: "Birla Cement (Mixed)",
    text: "Booking for Birla Cement, Mumbai to Bangalore, cement bags 15 tons, Taurus truck, rate 36k."
  },
  {
    title: "Reliance (English)",
    text: "Urgent shipment: Reliance Industries, Dhanbad to Kolkata, coal 40 Tonnes, trailer dumper required, billing at ₹29000 total rate."
  },
  {
    title: "Short Quick Route",
    text: "JSW Jamshedpur to Ranchi sariya 20 t Tata Taurus bhada 18000"
  },
];

export function ChatSimulator({ geminiConfigured }: ChatSimulatorProps) {
  const { 
    messages, setMessages, 
    inputText, setInputText, 
    isTyping, setIsTyping,
    activeExtraction, setActiveExtraction,
    aiEnginePayload, setAiEnginePayload,
    lastApiMode, setLastApiMode,
    extractionResponseTime, setExtractionResponseTime 
  } = useAiStore();

  const { customTables, activeTableId, handleAddRow } = useTableStore();

  const chatFeedRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatFeedRef.current) {
      chatFeedRef.current.scrollTo({
        top: chatFeedRef.current.scrollHeight,
        behavior: "smooth"
      });
    }
  }, [messages, isTyping]);

  const handleSend = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed) return;

    // Add user message locally
    const timeString = new Date().toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    });

    const userMessageId = "msg-" + Date.now();
    const newUserMessage: ChatMessage = {
      id: userMessageId,
      sender: "user",
      text: trimmed,
      timestamp: timeString
    };

    setMessages((prev: ChatMessage[]) => {
      const next = [...prev, newUserMessage];
      return next.length > 50 ? next.slice(next.length - 50) : next;
    });
    setInputText("");
    setIsTyping(true);
    setActiveExtraction(null);

    const startTime = performance.now();

    try {
      // Stream extraction payload to express backend
      const res = await fetch("/api/simulate-extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          message: trimmed,
          activeTableId,
          tablesSchema: customTables?.map(t => ({ id: t.id, name: t.name, columns: t.columns }))
        })
      });

      if (!res.body) throw new Error("No response body.");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      
      let finalData: any = null;
      let streamedResponse = "";

      // Add a temporary typing message
      const botTypingId = "bot-typing-" + Date.now();
      const botTypingMessage: ChatMessage = {
        id: botTypingId,
        sender: "bot",
        text: "...",
        timestamp: timeString
      };
      setMessages((prev: ChatMessage[]) => [...prev, botTypingMessage]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunkStr = decoder.decode(value, { stream: true });
        const lines = chunkStr.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6);
            if (dataStr) {
               try {
                 const parsed = JSON.parse(dataStr);
                 if (parsed.chunk) {
                    streamedResponse += parsed.chunk;
                    // Try to show only reasoning or reply logically, or just raw JSON to show progress
                    const displayText = streamedResponse.includes('"reply":') 
                        ? "Typing response..." 
                        : "Thinking...\n" + streamedResponse.slice(0, 50) + "...";
                        
                    setMessages((prev: ChatMessage[]) => prev.map((m: ChatMessage) => 
                      m.id === botTypingId ? { ...m, text: "Wait, parsing intent...\n```json\n" + streamedResponse + "\n```" } : m
                    ));
                 }
                 if (parsed.success) {
                    finalData = parsed;
                 }
               } catch(e) {}
            }
          }
        }
      }

      const endTime = performance.now();
      setExtractionResponseTime(Math.round(endTime - startTime));
      
      // Remove typing message
      setMessages((prev: ChatMessage[]) => prev.filter((m: ChatMessage) => m.id !== botTypingId));
      
      const data = finalData;

      if (data && data.success && data.extracted) {
        const ext = data.extracted;
        const aiPayload = data.aiEnginePayload;
        setLastApiMode(data.mode);
        setActiveExtraction(ext);
        if (aiPayload) {
          setAiEnginePayload(aiPayload);
        }

        // Generate Booking ID and formatted post
        const bookingId = "BK" + Math.floor(10000000 + Math.random() * 90000000).toString();
        
        // Format date and time
        const dateFormatted = new Date().toLocaleDateString("en-IN", {
          day: "2-digit",
          month: "short",
          year: "numeric"
        }) + " " + new Date().toLocaleTimeString("en-IN", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true
        });

        if (ext.conversation_reply) {
          const botMessage: ChatMessage = {
            id: "bot-" + Date.now(),
            sender: "bot",
            text: ext.conversation_reply,
            timestamp: timeString,
            extractedData: ext,
            apiMode: data.mode
          };
          setMessages((prev: ChatMessage[]) => [...prev, botMessage]);
        } else {
          // Find target table to dynamically display what was parsed
          const targetTable = customTables?.find(t => t.id === data.targetTableId);
          const tableName = targetTable ? targetTable.name : "Target Table";
          
          let breakdownText = "";
          for (const key in ext) {
             breakdownText += `▪️ *${key}:* ${ext[key] || "—"}\n`;
          }

          // 1. Create the WhatsApp formatted text
          const replyText = `✅ *DATA EXTRACTED!*\n━━━━━━━━━━━━━━━━━━━\n\n🆔 *Row ID:* ${bookingId}\n📁 *Target:* ${tableName}\n\n${breakdownText} \n━━━━━━━━━━━━━━━━━━━\n\n_Syncing to Database..._`;

          // 2. Add bot reply to chat
          const botMessage: ChatMessage = {
            id: "bot-" + Date.now(),
            sender: "bot",
            text: replyText,
            timestamp: timeString,
            extractedData: ext,
            apiMode: data.mode
          };

          setMessages((prev: ChatMessage[]) => [...prev, botMessage]);

          // 3. Sync newly parsed rows back to spreadsheet database
          const newRowData = { ...ext, timestamp: dateFormatted, id: bookingId, status: "Pending", source: "via WhatsApp" };
          
          handleAddRow(data.targetTableId || activeTableId || "transport_bookings", newRowData);
        }

      } else {
        throw new Error(data.error || "Faulty response from extraction api.");
      }

    } catch (e: any) {
      console.error(e);
      const botErrorMessage: ChatMessage = {
        id: "bot-err-" + Date.now(),
        sender: "bot",
        text: `⚠️ *Extraction Error* \n\nI was unable to automatically parse booking telemetry. Please review connection status or try again.\n\n_Detail: ${e.message || "Network Timeout"}_`,
        timestamp: timeString
      };
      setMessages((prev: ChatMessage[]) => [...prev, botErrorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend(inputText);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col">
      <div className="w-full bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/85 rounded-2xl shadow-sm overflow-hidden flex flex-col h-[750px] relative">
        
        {/* Modern Assistant Header Panel */}
        <div className="bg-slate-900 dark:bg-slate-950 text-white p-4 flex items-center justify-between border-b border-slate-800 shrink-0 z-10 select-none">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <h3 className="text-sm font-bold tracking-wide">Booking Assistant</h3>
          </div>
        </div>

        {/* Premium Chat Dialogue Feed Area */}
        <div ref={chatFeedRef} className="bg-slate-50/60 dark:bg-slate-950/40 flex-1 overflow-y-auto p-4 flex flex-col gap-4 relative">
          
          {/* Session Indicator Banner */}
          <div className="mx-auto bg-slate-200/60 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 text-[10px] uppercase font-bold tracking-widest px-3 py-1 rounded-full self-center border border-slate-250/30 dark:border-slate-700/30 select-none">
            Active Integration Session
          </div>

          {/* Bubble Rendering lists */}
          {messages.filter(Boolean).map((m) => {
            const isBot = m.sender === "bot";
            return (
              <div
                key={m.id}
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm sm:text-base relative font-sans ${
                  isBot
                    ? "bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/80 text-slate-850 dark:text-slate-100 rounded-tl-none self-start shadow-[0_2px_12px_rgba(0,0,0,0.02)]"
                    : "bg-indigo-600 text-white rounded-tr-none self-end shadow-[0_2px_12px_rgba(99,102,241,0.15)]"
                }`}
              >
                <p className="whitespace-pre-wrap select-text leading-relaxed tracking-wide">
                  {/* Convert simple *bold* and _italic_ to styled elements */}
                  {(m.text || "").split("\n").map((line, lineIdx) => (
                    <span key={lineIdx} className="block">
                      {line.split(/(?=\*|_)|(?<=\*|_)/g).map((part, partIdx) => {
                        if (part.startsWith("*") && part.endsWith("*")) {
                          return <strong key={partIdx} className={`font-bold ${isBot ? 'text-slate-900 dark:text-white' : 'text-white'}`}>{part.slice(1, -1)}</strong>;
                        } else if (part.startsWith("_") && part.endsWith("_")) {
                          return <em key={partIdx} className={`italic ${isBot ? 'text-slate-550 dark:text-slate-400' : 'text-indigo-105'}`}>{part.slice(1, -1)}</em>;
                        }
                        return part;
                      })}
                    </span>
                  ))}
                </p>
                <div className={`flex items-center justify-end gap-1 mt-1.5 text-[10px] sm:text-xs font-mono select-none ${isBot ? 'text-slate-400 dark:text-slate-500' : 'text-indigo-200'}`}>
                  <span>{m.timestamp || ""}</span>
                  {!isBot && <CheckCheck className="w-3.5 h-3.5 text-indigo-300" />}
                </div>
              </div>
            );
          })}

          {/* Typing status */}
          {isTyping && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl rounded-tl-none px-4 py-3 text-sm sm:text-base border border-slate-150 dark:border-slate-800 shadow-sm self-start flex items-center gap-2">
              <span className="font-semibold text-indigo-650 dark:text-indigo-400 animate-pulse font-sans">Processing payload...</span>
              <span className="flex gap-1 items-center h-2">
                <span className="bg-indigo-600 dark:bg-indigo-505 w-1 h-1 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                <span className="bg-indigo-600 dark:bg-indigo-505 w-1 h-1 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                <span className="bg-indigo-600 dark:bg-indigo-505 w-1 h-1 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
              </span>
            </div>
          )}
        </div>

        {/* Modern Input Bar */}
        <div className="bg-white dark:bg-slate-900 p-3.5 border-t border-slate-200/60 dark:border-slate-800/80 flex items-center gap-2.5 shrink-0">
          <input
            type="text"
            autoComplete="off"
            spellCheck={false}
            className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl px-4 py-3 text-sm sm:text-base focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-550 dark:focus:ring-indigo-500 font-sans text-slate-900 dark:text-slate-100 transition-all placeholder-slate-400"
            placeholder="Type a whatsapp transport load details message..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyPress}
            disabled={isTyping}
          />
          <button
            onClick={() => handleSend(inputText)}
            disabled={isTyping || !inputText.trim()}
            className={`p-3 rounded-xl cursor-pointer transition ${
              inputText.trim() && !isTyping
                ? "bg-indigo-600 hover:bg-indigo-700 text-white"
                : "bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed"
            }`}
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
