import React from 'react';
import { useMechanicStore } from '../../store/mechanicStore';
import { Wrench, Plus, FileText } from 'lucide-react';

export function MechanicManagement() {
  const { mechanics } = useMechanicStore();

  return (
    <div className="flex flex-col h-full gap-6 animate-fadeIn">
      {/* Header section */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Wrench className="w-6 h-6 text-orange-500" />
            Mechanic Directory
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your network of transport mechanics, workshops, and their specializations.
          </p>
        </div>
        <button className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" />
          Add Mechanic
        </button>
      </div>

      {/* Main Content: Mechanic List */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden flex-1 flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-6 py-4">Mechanic/Workshop Name</th>
                <th className="px-6 py-4">Contact & Location</th>
                <th className="px-6 py-4">Specialization</th>
                <th className="px-6 py-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {mechanics.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-slate-500">
                    No mechanics found. Click "Add Mechanic" to create one.
                  </td>
                </tr>
              ) : (
                mechanics.map((mechanic) => (
                  <tr key={mechanic.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group cursor-pointer">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">
                        {mechanic.name}
                      </div>
                      {mechanic.extraNotes && (
                        <div className="text-xs text-slate-500 mt-1 flex items-start gap-1">
                          <FileText className="w-3 h-3 mt-[2px] shrink-0" />
                          <span className="truncate max-w-[200px]">{mechanic.extraNotes}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-mono text-xs">{mechanic.phone}</div>
                      <div className="text-slate-500 text-xs mt-1">{mechanic.workshopLocation || 'No location specified'}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300">
                        {mechanic.specialization || 'General'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border
                        ${mechanic.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20' : 
                          'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'}
                      `}>
                        {mechanic.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
