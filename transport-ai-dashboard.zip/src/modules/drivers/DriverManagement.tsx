import React from 'react';
import { useDriverStore } from '../../store/driverStore';
import { Users, Plus, IndianRupee, FileText } from 'lucide-react';

export function DriverManagement() {
  const { drivers } = useDriverStore();

  return (
    <div className="flex flex-col h-full gap-6 animate-fadeIn">
      {/* Header section */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-500" />
            Driver Management
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your transport drivers, track cash advances, and view compliance status.
          </p>
        </div>
        <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" />
          Add Driver
        </button>
      </div>

      {/* Main Content: Driver List */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden flex-1 flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-6 py-4">Driver Name</th>
                <th className="px-6 py-4">Contact</th>
                <th className="px-6 py-4">License & Expiry</th>
                <th className="px-6 py-4 text-right">Advance Balance</th>
                <th className="px-6 py-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {drivers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-500">
                    No drivers found. Click "Add Driver" to create one.
                  </td>
                </tr>
              ) : (
                drivers.map((driver) => (
                  <tr key={driver.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group cursor-pointer">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">
                        {driver.name}
                      </div>
                      {driver.extraNotes && (
                        <div className="text-xs text-slate-500 mt-1 flex items-start gap-1">
                          <FileText className="w-3 h-3 mt-[2px] shrink-0" />
                          <span className="truncate max-w-[200px]">{driver.extraNotes}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 font-mono text-xs">{driver.phone}</td>
                    <td className="px-6 py-4">
                      <div className="text-slate-900 dark:text-slate-200">{driver.licenseNumber || '-'}</div>
                      {/* Would format real dates nicely here */}
                    </td>
                    <td className="px-6 py-4 font-mono font-medium text-right text-slate-900 dark:text-slate-100 flex items-center justify-end gap-1">
                      <IndianRupee className="w-3 h-3 text-slate-400" />
                      {driver.cachedAdvanceBalance.toLocaleString('en-IN')}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border
                        ${driver.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20' : 
                          driver.status === 'On Leave' ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/20' : 
                          'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'}
                      `}>
                        {driver.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
