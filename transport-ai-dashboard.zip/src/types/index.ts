export interface Booking {
  id: string;
  timestamp: string;
  customer: string;
  pickup: string;
  destination: string;
  material: string;
  weight: string;
  truckType: string;
  rate: string;
  status: 'Pending' | 'Confirmed' | 'Dispatched' | 'Completed' | 'Cancelled';
  source: string;
}

export interface TableColumn {
  id: string;
  name: string;
  type: 'text' | 'phone' | 'email' | 'status' | 'number' | 'date' | 'location' | 'driver' | 'money' | 'tags';
}

export interface TableRow {
  id: string;
  [key: string]: any;
}

export interface CustomTable {
  id: string;
  name: string;
  columns: TableColumn[];
  rows: TableRow[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'system';
  text: string;
  timestamp: string;
  extractedData?: Record<string, any>; // Relaxed to handle any table
  targetTableId?: string; // which table this belongs to
  apiMode?: string;
}

// --- SHARED BASE MODELS ---

export interface AuditInfo {
  createdAt?: string; // Optional for now to maintain mock compatibility
  updatedAt?: string;
  createdBy?: string;
}

export interface Address {
  street?: string;
  city?: string;
  state?: string;
  pincode?: string;
}

export interface DocumentResource {
  id: string;
  type: string; // e.g., 'License', 'Insurance', 'Invoice', 'Permit'
  name: string;
  url: string;
  uploadDate: string;
  expiryDate?: string;
  linkedEntityType?: 'Party' | 'Driver' | 'Vehicle' | 'Trip' | 'Transaction';
  linkedEntityId?: string;
}

// Base Entity to enforce consistency across all master data
export interface BaseEntity extends AuditInfo {
  id: string;
  status: 'Active' | 'Inactive' | string;
  documents: DocumentResource[];
  extraNotes?: string; // Flexible remarks
}

// --- FINANCIAL LEDGER (IMMUTABLE TRANSACTIONS) ---

export type TransactionType = 
  | 'DRIVER_ADVANCE' 
  | 'DRIVER_SETTLEMENT'
  | 'PARTY_PAYMENT_RECEIVED' 
  | 'PARTY_FREIGHT_BILLED'
  | 'MECHANIC_PAYMENT' 
  | 'VEHICLE_EXPENSE' 
  | 'TRIP_EXPENSE';

export type PaymentMethod = 'Cash' | 'Bank Transfer' | 'UPI' | 'Cheque';

export interface LedgerTransaction extends AuditInfo {
  id: string;
  type: TransactionType;
  amount: number;
  date: string;
  partyId?: string;
  driverId?: string;
  vehicleId?: string;
  mechanicId?: string;
  tripId?: string;
  paymentMethod: PaymentMethod;
  referenceNumber?: string; // UPI ref, Cheque no
  remarks?: string; // Always allow remarks on financial transactions
}

// --- CORE OPERATIONAL MODELS ---

export interface Trip extends BaseEntity {
  bookingDate: string;
  partyId: string; // Relational tie to Party
  driverId?: string; // Relational tie to Driver
  vehicleId?: string; // Relational tie to Vehicle
  
  pickupLocation: string;
  dropLocation: string;
  
  materialDescription?: string;
  weight?: string; // e.g. "15 MT"
  
  // Financial summaries tied to Ledger
  freightAmount: number;
  advanceGiven: number; 
  bilibiltyStatus: 'Pending' | 'Billed' | 'Settled';
  
  status: 'Pending' | 'Confirmed' | 'Dispatched' | 'In Transit' | 'Unloaded' | 'Completed' | 'Cancelled';
}

// --- NEW MASTER DATA SCHEMAS ---

export interface Party extends BaseEntity {
  name: string;
  phone: string;
  contactPerson?: string;
  address?: string; // Keeping as string or Address type based on flexibility needed
  cachedOutstandingBalance: number; // Replaced direct balance with 'cached' to emphasize ledger-based calculation
}

export interface Driver extends BaseEntity {
  name: string;
  phone: string;
  licenseNumber?: string;
  licenseExpiry?: string;
  cachedAdvanceBalance: number; // Replaced direct balance with 'cached'
  status: 'Active' | 'On Leave' | 'Inactive';
}

export interface Vehicle extends BaseEntity {
  registrationNumber: string;
  type: string; // e.g., Open, Container, Trailer
  capacity?: string; // e.g., 20 MT
  fitnessExpiry?: string;
  insuranceExpiry?: string;
  status: 'Available' | 'On Trip' | 'Under Repair' | 'Inactive';
}

export interface Mechanic extends BaseEntity {
  name: string;
  phone: string;
  workshopLocation?: string;
  specialization?: string; // e.g., Engine, Tyres, Electrical
}

