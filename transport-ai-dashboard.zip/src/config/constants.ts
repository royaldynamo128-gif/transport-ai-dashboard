import { CustomTable, TableColumn } from '../types';

export const TRANSPORT_COLUMNS: TableColumn[] = [
  { id: "timestamp", name: "Timestamp", type: "text" },
  { id: "customer", name: "Customer", type: "text" },
  { id: "pickup", name: "Pickup", type: "text" },
  { id: "destination", name: "Destination", type: "text" },
  { id: "material", name: "Material", type: "text" },
  { id: "weight", name: "Weight", type: "text" },
  { id: "truckType", name: "Truck Type", type: "text" },
  { id: "rate", name: "Rate", type: "text" },
  { id: "status", name: "Status", type: "status" },
  { id: "source", name: "Source", type: "text" }
];

export const OTHER_DEFAULT_TABLES: CustomTable[] = [
  {
    id: "customer_details",
    name: "Customer Details",
    columns: [
      { id: "customer_name", name: "Customer Name", type: "text" },
      { id: "phone", name: "Phone Number", type: "phone" },
      { id: "address", name: "Address", type: "text" },
      { id: "industry", name: "Industry Type", type: "text" }
    ],
    rows: []
  },
  {
    id: "driver_details",
    name: "Driver Details",
    columns: [
      { id: "driver_name", name: "Driver Name", type: "text" },
      { id: "phone", name: "Mobile", type: "phone" },
      { id: "truck_number", name: "Truck Number", type: "text" },
      { id: "truck_type", name: "Truck Type", type: "text" }
    ],
    rows: []
  }
];
